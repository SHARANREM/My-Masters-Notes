# Gradient_Descent.py - Stochastic Gradient Descent Optimizer Simulation
import math

def compute_cost(X, y, w, b):
    m = len(X)
    cost = 0.0
    for i in range(m):
        f_wb = w * X[i] + b
        cost += (f_wb - y[i]) ** 2
    return cost / (2 * m)

def compute_gradient(X, y, w, b):
    m = len(X)
    dj_dw = 0.0
    dj_db = 0.0
    for i in range(m):
        f_wb = w * X[i] + b
        dj_dw += (f_wb - y[i]) * X[i]
        dj_db += (f_wb - y[i])
    return dj_dw / m, dj_db / m

def gradient_descent(X, y, w_in, b_in, alpha, num_iters):
    w = w_in
    b = b_in
    for i in range(num_iters):
        dj_dw, dj_db = compute_gradient(X, y, w, b)
        w -= alpha * dj_dw
        b -= alpha * dj_db
        if i % 100 == 0:
            cost = compute_cost(X, y, w, b)
            print(f"Iteration {i:4d}: Cost {cost:8.4f} | w: {w:8.4f} | b: {b:8.4f}")
    return w, b

if __name__ == "__main__":
    X_train = [1.0, 2.0, 3.0, 4.0, 5.0]
    y_train = [3.0, 5.0, 7.0, 9.0, 11.0] # y = 2x + 1
    w_final, b_final = gradient_descent(X_train, y_train, 0.0, 0.0, 0.01, 1000)
    print(f"\nFinal Learned Model: y = {w_final:.2f}x + {b_final:.2f}")
