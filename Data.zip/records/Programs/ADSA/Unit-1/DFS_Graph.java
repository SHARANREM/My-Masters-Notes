// DFS_Graph.java - Depth First Search Traversal
import java.util.*;

public class DFS_Graph {
    private int V; // No. of vertices
    private LinkedList<Integer>[] adj; // Adjacency Lists

    @SuppressWarnings("unchecked")
    public DFS_Graph(int v) {
        V = v;
        adj = new LinkedList[v];
        for (int i = 0; i < v; ++i) {
            adj[i] = new LinkedList<>();
        }
    }

    public void addEdge(int v, int w) {
        adj[v].add(w);
    }

    private void DFSUtil(int v, boolean[] visited) {
        visited[v] = true;
        System.out.print(v + " ");

        for (int n : adj[v]) {
            if (!visited[n]) {
                DFSUtil(n, visited);
            }
        }
    }

    public void DFS(int v) {
        boolean[] visited = new boolean[V];
        System.out.println("Depth First Search starting from vertex " + v + ":");
        DFSUtil(v, visited);
        System.out.println();
    }

    public static void main(String[] args) {
        DFS_Graph g = new DFS_Graph(5);
        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(1, 2);
        g.addEdge(2, 0);
        g.addEdge(2, 3);
        g.addEdge(3, 3);
        g.addEdge(1, 4);

        g.DFS(2);
    }
}
