# Big_Oh.py - Empirical Time Complexity Analyzer
import time
import random

def linear_search(arr, target):
    """O(N) Time Complexity"""
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1

def binary_search(arr, target):
    """O(log N) Time Complexity on sorted array"""
    low = 0
    high = len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1

if __name__ == "__main__":
    size = 1_000_000
    data = sorted([random.randint(1, 10_000_000) for _ in range(size)])
    target = data[-1]

    # Measure Linear Search
    t0 = time.perf_counter()
    linear_search(data, target)
    t1 = time.perf_counter()
    print(f"Linear Search O(N) took: {(t1 - t0) * 1000:.4f} ms")

    # Measure Binary Search
    t0 = time.perf_counter()
    binary_search(data, target)
    t1 = time.perf_counter()
    print(f"Binary Search O(log N) took: {(t1 - t0) * 1000:.4f} ms")
