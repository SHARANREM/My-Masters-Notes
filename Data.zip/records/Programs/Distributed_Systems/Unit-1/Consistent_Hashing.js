// Consistent_Hashing.js - Hash Ring for Distributed Systems
import crypto from 'crypto';

class ConsistentHashRing {
  constructor(replicas = 3) {
    this.replicas = replicas;
    this.ring = new Map();
    this.sortedKeys = [];
  }

  hash(key) {
    const hex = crypto.createHash('md5').update(key).digest('hex');
    return parseInt(hex.substring(0, 8), 16);
  }

  addNode(node) {
    for (let i = 0; i < this.replicas; i++) {
      const vNodeKey = `${node}-vnode-${i}`;
      const hash = this.hash(vNodeKey);
      this.ring.set(hash, node);
      this.sortedKeys.push(hash);
    }
    this.sortedKeys.sort((a, b) => a - b);
  }

  removeNode(node) {
    for (let i = 0; i < this.replicas; i++) {
      const vNodeKey = `${node}-vnode-${i}`;
      const hash = this.hash(vNodeKey);
      this.ring.delete(hash);
    }
    this.sortedKeys = this.sortedKeys.filter(k => this.ring.has(k));
  }

  getNode(key) {
    if (this.sortedKeys.length === 0) return null;
    const hash = this.hash(key);
    for (const k of this.sortedKeys) {
      if (hash <= k) return this.ring.get(k);
    }
    return this.ring.get(this.sortedKeys[0]);
  }
}

// Test Ring
const ring = new ConsistentHashRing(3);
ring.addNode('Server-A');
ring.addNode('Server-B');
ring.addNode('Server-C');

console.log('Key "user_session_101" maps to:', ring.getNode('user_session_101'));
console.log('Key "user_session_202" maps to:', ring.getNode('user_session_202'));
