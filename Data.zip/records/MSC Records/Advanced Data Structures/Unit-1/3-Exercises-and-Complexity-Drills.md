# Exercises & Complexity Drills

This lesson contains problem sets, complexity derivations, and C++ code implementations for Breadth-First Search (BFS) and queue-based graph traversals.

---

## 1. C++ Breadth-First Search (BFS) Implementation

Breadth-First Search visits vertices level by level using a FIFO queue. Time complexity is $O(V + E)$ and space complexity is $O(V)$.

::code
records/Programs/ADSA/Unit-1/BFS_Graph.cpp
::

---

## 2. Practice Questions

::success
Completed Problem 1: Prove that $\log(n!) = \Theta(n \log n)$ using Stirling's Approximation.
::

::note
Problem 2: Find the tight bound $\Theta$ for $T(n) = 4 T(n/2) + n^2 \log n$.
Hint: Use Master Theorem Case 2 extended version.
::

---

## 3. Reference Notes & Handwritten Solutions

::handwritten
public/assets/handwritten/Lecture-1-Asymptotic-Notation.pdf
::

::folder
records/Programs/ADSA/Unit-1
::
