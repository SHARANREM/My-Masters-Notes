# Welcome to Algorithms

An **Algorithm** is a finite sequence of well-defined instructions designed to solve a specific problem or perform a particular task. Every computer program, from a simple calculator to modern Artificial Intelligence systems, follows one or more algorithms to process data and produce meaningful results.

An algorithm is independent of any programming language. It describes **what should be done**, while a programming language describes **how it is implemented**.

---

::tip
An algorithm is like a recipe for cooking. The ingredients are the input, the cooking steps are the algorithm, and the finished dish is the output.
::

---

# 1. Definition of an Algorithm

An algorithm is a **step-by-step procedure** that accepts an input, processes it according to predefined rules, and produces the required output.

Every algorithm must eventually terminate after a finite number of steps.

---

::image
assets/images/algorithm_flow.png
Basic flow of an Algorithm: Input → Process → Output
::

---

# 2. Structure of an Algorithm

Every algorithm consists of three basic stages.

### Input

The information provided to the algorithm.

Examples:

- Numbers
- Text
- Images
- User Commands

### Processing

A sequence of logical operations performed on the input.

Examples:

- Comparison
- Calculation
- Sorting
- Searching

### Output

The final result produced after processing.

---

::compare
Stage | Description | Example
Input | Data given to the algorithm | Two Numbers
Process | Logical steps performed | Compare Values
Output | Final result | Largest Number
::

---

# 3. Characteristics of a Good Algorithm

A good algorithm should satisfy the following properties.

### 1. Input

The algorithm should accept zero or more inputs.

### 2. Output

The algorithm must produce at least one meaningful output.

### 3. Definiteness

Each instruction must be clear and unambiguous.

### 4. Finiteness

The algorithm should terminate after a finite number of steps.

### 5. Effectiveness

Every instruction should be simple enough to be executed within a finite amount of time.

### 6. Correctness

The algorithm should always produce the expected result for valid inputs.

---

::note
Remember these six characteristics:

**Input • Output • Definiteness • Finiteness • Effectiveness • Correctness**
::

---

# 4. Real-Life Examples of Algorithms

Algorithms are used in everyday life.

### Example 1 – Making Tea

1. Boil water.
2. Add tea powder.
3. Add sugar.
4. Add milk.
5. Boil for two minutes.
6. Filter and serve.

### Example 2 – ATM Cash Withdrawal

1. Insert ATM card.
2. Enter PIN.
3. Select Withdraw.
4. Enter amount.
5. Verify balance.
6. Dispense cash.
7. Print receipt.

---

::image
assets/images/algorithm_examples.jpg
Algorithms are used in daily activities such as cooking, banking, and navigation.
::

---

# 5. Algorithm Example

### Problem

Find the larger of two numbers.

### Algorithm

1. Start
2. Read two numbers A and B
3. Compare A and B
4. If A > B, print A
5. Otherwise, print B
6. Stop

---

::code
records/Programs/ADSA/Unit-1/Largest_Number.py
::

---

# 6. Why are Algorithms Important?

Algorithms help computers solve problems efficiently.

They are used in:

- Search Engines
- Banking Software
- Artificial Intelligence
- Navigation Systems
- Online Shopping
- Medical Applications
- Robotics
- Computer Games

---

::compare
Without Algorithms | With Algorithms
Slow Programs | Faster Programs
Higher Memory Usage | Better Memory Management
Complex Solutions | Organized Solutions
Poor Performance | Optimized Performance
::

---

# 7. Qualities of an Efficient Algorithm

An efficient algorithm should:

- Solve the problem correctly.
- Use minimum execution time.
- Consume less memory.
- Be easy to understand.
- Be easy to maintain.
- Produce consistent results.

---

::important
The goal of an algorithm is not only to solve a problem, but to solve it efficiently.
::

---

# 8. Applications of Algorithms

Algorithms are used in almost every field of Computer Science.

- Operating Systems
- Artificial Intelligence
- Machine Learning
- Databases
- Web Applications
- Mobile Applications
- Cyber Security
- Networking
- Data Science
- Cloud Computing

---

::success
Every software application you use today runs thousands of algorithms every second behind the scenes.
::

---

# 9. Summary

- An algorithm is a step-by-step procedure.
- Every algorithm has an Input, Process, and Output.
- A good algorithm is Correct, Finite, Effective, and Unambiguous.
- Algorithms are independent of programming languages.
- Efficient algorithms improve software performance.

---

# 10. Practice Exercises

### Basic

- [ ] Define an Algorithm.
- [ ] List the characteristics of an Algorithm.
- [ ] Explain Input, Process, and Output.

### Intermediate

- [ ] Write an algorithm to calculate the area of a circle.
- [ ] Write an algorithm to determine whether a number is even or odd.
- [ ] Write an algorithm to find the largest among three numbers.

### Advanced

- [ ] Design an algorithm to calculate the factorial of a number.
- [ ] Write an algorithm for Linear Search.
- [ ] Write an algorithm for Binary Search (logic only).

---

# 11. Additional Resources

## Recommended Video

::yt
https://www.youtube.com/watch?v=6hfOvs8pY1k
::

---

## Reference Notes

::pdf
public/assets/handwritten/Algorithms_Introduction.pdf
::
