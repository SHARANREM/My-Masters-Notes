# Red-Black Trees and B-Trees

Red-Black Trees and B-Trees are essential balanced search tree structures used heavily in database indexing, file systems (such as ext4 and NTFS), and memory management.

---

## 1. Red-Black Tree Properties

A Red-Black Tree is a binary search tree where each node stores an extra bit representing color (RED or BLACK). It satisfies five invariants:

1. Every node is either RED or BLACK.
2. The root is always BLACK.
3. Every leaf (NIL) is BLACK.
4. If a node is RED, both its children are BLACK (No two consecutive RED nodes).
5. For each node, all simple paths from the node to descendant leaves contain the same number of BLACK nodes.

::tip
The maximum height of a Red-Black Tree with $n$ internal nodes is $2 \log_2(n + 1)$.
::

---

## 2. B-Trees and Disk I/O Optimization

B-Trees are multi-way search trees optimized for storage systems where block reads/writes are expensive.

- Each node can contain up to $M-1$ keys and $M$ child pointers.
- Minimizes disk page fetches during large database searches.

::assignment
records/Assignments/ADSA/Assignment-2.pdf
::
