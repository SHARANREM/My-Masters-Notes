# AVL Trees and Rotation Balancing

An **AVL Tree** (named after Adelson-Velsky and Landis) is a self-balancing binary search tree where the heights of any node's two child subtrees differ by at most one.

---

## 1. Balance Factor Definition

For any node $v$ in an AVL tree:

$$\text{BalanceFactor}(v) = \text{height}(\text{LeftSubtree}) - \text{height}(\text{RightSubtree})$$

Valid Balance Factor values for an AVL tree node are strictly $\{-1, 0, 1\}$.

::warning
If $|\text{BalanceFactor}(v)| > 1$, a tree rotation must be triggered immediately to restore equilibrium.
::

---

## 2. Four Types of Rotations

1. **Left-Left (LL) Violation**: Restored using a Single Right Rotation.
2. **Right-Right (RR) Violation**: Restored using a Single Left Rotation.
3. **Left-Right (LR) Violation**: Restored using Double Rotation (Left Rotation on child, then Right Rotation on node).
4. **Right-Left (RL) Violation**: Restored using Double Rotation (Right Rotation on child, then Left Rotation on node).

---

## 3. C Implementation of AVL Tree Balancing

::code
records/Programs/ADSA/Unit-2/AVL_Tree_Operations.c
::

---

## 4. Performance Metrics

::compare
**Operation** | **Average Case** | **Worst Case**
Search | $O(\log n)$ | $O(\log n)$
Insertion | $O(\log n)$ | $O(\log n)$
Deletion | $O(\log n)$ | $O(\log n)$
Space | $O(n)$ | $O(n)$
::

---

## 5. Handwritten Rotations Diagrams

::handwritten
public/assets/handwritten/Lecture-5-AVL-Tree-Rotations.pdf
::
