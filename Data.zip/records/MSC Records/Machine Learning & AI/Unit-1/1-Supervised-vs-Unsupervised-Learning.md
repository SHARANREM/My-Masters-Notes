# Supervised vs Unsupervised Machine Learning

Machine Learning models learn patterns from empirical data. We categorize models based on supervision signal availability.

---

## 1. Supervised Learning Paradigm

Supervised learning maps inputs $X \in \mathbb{R}^d$ to labels $Y \in \mathcal{Y}$ given dataset $\mathcal{D} = \{(x_i, y_i)\}_{i=1}^N$.

- **Regression**: $Y \in \mathbb{R}$ (e.g. predicting house prices)
- **Classification**: $Y \in \{1, 2, \dots, C\}$ (e.g. spam detection)

::important
Overfitting occurs when a high-capacity model memorizes noise in training data. Use L1/L2 regularization to bound weights.
::

---

## 2. Unsupervised Learning Paradigm

Unsupervised algorithms discover latent structures in unlabeled datasets $\mathcal{D} = \{x_i\}_{i=1}^N$.

- **Clustering**: K-Means, DBSCAN, Hierarchical Clustering
- **Dimensionality Reduction**: Principal Component Analysis (PCA), t-SNE, UMAP

::code
records/Programs/ML_AI/Unit-1/Gradient_Descent.py
::

---

## 3. Past Question Paper

::questionpaper
records/Question Paper Images/ML_AI/2023_End_Semester_Exam.pdf
::

::assignment
records/Assignments/ML_AI/Assignment-1-Regression.pdf
::
