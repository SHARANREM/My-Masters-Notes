# CAP Theorem and Consensus Protocols

In distributed systems design, the **CAP Theorem** (Brewster's Theorem) defines fundamental trade-offs for distributed data stores.

---

## 1. CAP Theorem Principles

When a network partition occurs, a distributed system can satisfy at most **two** out of three guarantees:

1. **Consistency (C)**: Every read receives the most recent write or an error.
2. **Availability (A)**: Every non-failing node returns a non-error response without guarantee it contains the most recent write.
3. **Partition Tolerance (P)**: System continues operating despite dropped or delayed network packets.

::tip
Since physical networks inevitably experience packet drops (Partitions occur), distributed databases must choose between **CP** (e.g., MongoDB, HBase, Spanner) or **AP** (e.g., Cassandra, DynamoDB).
::

---

## 2. Consistent Hashing Code Implementation

Below is a JavaScript implementation of a hash ring with virtual nodes for distributed data partitioning:

::code
records/Programs/Distributed_Systems/Unit-1/Consistent_Hashing.js
::

---

## 3. Raft Consensus Algorithm Assignment

::assignment
records/Assignments/Distributed_Systems/Assignment-1-Raft.pdf
::

::questionpaper
records/Question Paper Images/Distributed_Systems/2024_Class_Test.png
::
