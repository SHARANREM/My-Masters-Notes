import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { DataProvider, useData } from './contexts/DataContext';
import { BookmarkProvider } from './contexts/BookmarkContext';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import SearchModal from './components/modals/SearchModal';
import MscRecordsPage from './pages/MscRecordsPage';
import ProgramsPage from './pages/ProgramsPage';
import AssignmentsPage from './pages/AssignmentsPage';
import QuestionPapersPage from './pages/QuestionPapersPage';
import HandwrittenNotesPage from './pages/HandwrittenNotesPage';
import BookmarksPage from './pages/BookmarksPage';
import RecentPage from './pages/RecentPage';

function AppContent() {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const { isSearchOpen, setIsSearchOpen } = useData();

  return (
    <div className="min-h-screen bg-[#0f1115] text-[#f5f7fa] flex flex-col font-sans selection:bg-[rgba(108,188,255,0.25)] selection:text-[#6cbcff]">
      {/* Navigation Header */}
      <Header isMobileOpen={isMobileSidebarOpen} setIsMobileOpen={setIsMobileSidebarOpen} />

      {/* Main Route Content */}
      <div className="flex-1 flex flex-col">
        <Routes>
          <Route
            path="/"
            element={
              <MscRecordsPage
                isMobileSidebarOpen={isMobileSidebarOpen}
                setIsMobileSidebarOpen={setIsMobileSidebarOpen}
              />
            }
          />
          <Route path="/programs" element={<ProgramsPage />} />
          <Route path="/assignments" element={<AssignmentsPage />} />
          <Route path="/question-papers" element={<QuestionPapersPage />} />
          <Route path="/handwritten-notes" element={<HandwrittenNotesPage />} />
          <Route path="/bookmarks" element={<BookmarksPage />} />
          <Route path="/recent" element={<RecentPage />} />
        </Routes>
      </div>

      {/* Global Footer */}
      <Footer />

      {/* Global Quick Search Modal */}
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <BookmarkProvider>
      <DataProvider>
        <Router>
          <AppContent />
        </Router>
      </DataProvider>
    </BookmarkProvider>
  );
}
