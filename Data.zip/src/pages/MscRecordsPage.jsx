import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import { useBookmarks } from '../contexts/BookmarkContext';
import MarkdownViewer from '../components/markdown/MarkdownViewer';
import Breadcrumb from '../components/layout/Breadcrumb';
import RightTOC from '../components/layout/RightTOC';
import Sidebar from '../components/layout/Sidebar';
import {
  Bookmark,
  Check,
  Share2,
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Clock,
  PanelLeft,
  PanelRight,
  Maximize2,
} from 'lucide-react';

export default function MscRecordsPage({ isMobileSidebarOpen, setIsMobileSidebarOpen }) {
  const {
    contentTree,
    activeLesson,
    setActiveLesson,
    lessonScrollPositionsRef,
    lastActiveLessonIdRef,
  } = useData();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const [copiedLink, setCopiedLink] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isTOCCollapsed, setIsTOCCollapsed] = useState(false);

  // Scroll position handling: scroll to top when changing lesson; restore position when returning from other pages
  useEffect(() => {
    if (!activeLesson) return;

    const currentLessonId = activeLesson.id;

    if (lastActiveLessonIdRef.current !== currentLessonId) {
      // New lesson selected -> scroll to top
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      lastActiveLessonIdRef.current = currentLessonId;
    } else {
      // Same lesson (e.g. returning from Assignments) -> restore scroll Y
      const savedScrollY = lessonScrollPositionsRef.current[currentLessonId] || 0;
      window.scrollTo({ top: savedScrollY, left: 0, behavior: 'instant' });
    }

    const handleScroll = () => {
      if (activeLesson) {
        lessonScrollPositionsRef.current[activeLesson.id] = window.scrollY;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [activeLesson?.id]);

  const bookmarked = activeLesson ? isBookmarked(activeLesson.id) : false;

  // Flatten all lessons into linear list to derive Prev / Next navigation
  const flatLessons = useMemo(() => {
    const list = [];
    contentTree.forEach((subject) => {
      subject.units.forEach((unit) => {
        unit.lessons.forEach((lesson) => {
          list.push(lesson);
        });
      });
    });
    return list;
  }, [contentTree]);

  const currentIndex = useMemo(() => {
    if (!activeLesson) return -1;
    return flatLessons.findIndex((l) => l.id === activeLesson.id);
  }, [activeLesson, flatLessons]);

  const prevLesson = currentIndex > 0 ? flatLessons[currentIndex - 1] : null;
  const nextLesson = currentIndex >= 0 && currentIndex < flatLessons.length - 1 ? flatLessons[currentIndex + 1] : null;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="flex flex-1 min-h-[calc(100vh-3.5rem)] relative items-start">
      {/* Left VS Code Explorer Sidebar */}
      <Sidebar
        isOpen={isMobileSidebarOpen}
        onClose={() => setIsMobileSidebarOpen(false)}
        isDesktopCollapsed={isSidebarCollapsed}
        onToggleDesktop={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />

      {/* Main Reader View */}
      <main className="flex-1 min-w-0 px-4 sm:px-8 py-6">
        {activeLesson ? (
          <div className="max-w-4xl mx-auto">
            {/* Desktop Panel Collapse Quick Controls */}
            <div className="flex items-center justify-between gap-2 mb-4 pb-2 border-b border-[#222836]/60">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                  className={`px-2.5 py-1 rounded-md text-xs font-mono font-medium flex items-center gap-1.5 transition-all border ${
                    isSidebarCollapsed
                      ? 'bg-[#1e283a] text-[#38bdf8] border-[#2d3a52] hover:bg-[#25334a]'
                      : 'bg-[#161a23] text-[#94a3b8] border-[#222836] hover:text-[#f8fafc] hover:bg-[#1e2430]'
                  }`}
                  title={isSidebarCollapsed ? 'Show Lessons Sidebar' : 'Hide Lessons Sidebar'}
                >
                  <PanelLeft size={14} className={isSidebarCollapsed ? 'text-[#38bdf8]' : ''} />
                  <span>{isSidebarCollapsed ? 'Show Lessons' : 'Collapse Sidebar'}</span>
                </button>

                <button
                  onClick={() => setIsTOCCollapsed(!isTOCCollapsed)}
                  className={`hidden xl:flex px-2.5 py-1 rounded-md text-xs font-mono font-medium items-center gap-1.5 transition-all border ${
                    isTOCCollapsed
                      ? 'bg-[#1e283a] text-[#38bdf8] border-[#2d3a52] hover:bg-[#25334a]'
                      : 'bg-[#161a23] text-[#94a3b8] border-[#222836] hover:text-[#f8fafc] hover:bg-[#1e2430]'
                  }`}
                  title={isTOCCollapsed ? 'Show On This Page Panel' : 'Hide On This Page Panel'}
                >
                  <PanelRight size={14} className={isTOCCollapsed ? 'text-[#38bdf8]' : ''} />
                  <span>{isTOCCollapsed ? 'Show On This Page' : 'Collapse On This Page'}</span>
                </button>
              </div>

              {isSidebarCollapsed && isTOCCollapsed && (
                <span className="text-[11px] font-mono text-[#38bdf8] bg-[#1e283a] px-2 py-0.5 rounded border border-[#2d3a52] hidden sm:inline">
                  Distraction-Free Focus Mode
                </span>
              )}
            </div>

            {/* Breadcrumb */}
            <Breadcrumb
              subject={activeLesson.subjectName}
              unit={activeLesson.unitName}
              lessonTitle={activeLesson.title}
            />

            {/* Document Header */}
            <div className="mb-6 pb-6 border-b border-[#222836]">
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full bg-[#1e283a] text-[#38bdf8] border border-[#2d3a52] text-xs font-mono font-semibold uppercase tracking-wider">
                  {activeLesson.subjectName}
                </span>
                <span className="text-xs text-[#94a3b8] font-mono">{activeLesson.unitName}</span>
                <span className="text-xs text-[#64748b]">•</span>
                <span className="text-xs text-[#94a3b8] flex items-center gap-1 font-mono">
                  <Clock size={12} className="text-[#38bdf8]" /> {activeLesson.readingTime} min read
                </span>
              </div>

              <div className="flex items-start sm:items-center justify-between gap-4 flex-col sm:flex-row">
                <h1 className="text-2xl sm:text-3xl font-bold text-[#f8fafc] tracking-tight">
                  {activeLesson.title}
                </h1>

                {/* Toolbar Actions */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleBookmark(activeLesson)}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-all border ${
                      bookmarked
                        ? 'bg-[#38bdf8] text-[#0f1218] font-semibold border-[#38bdf8]'
                        : 'bg-[#161a23] border-[#222836] text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#1e2430]'
                    }`}
                  >
                    <Bookmark size={14} className={bookmarked ? 'fill-current' : ''} />
                    <span>{bookmarked ? 'Saved' : 'Bookmark'}</span>
                  </button>

                  <button
                    onClick={handleShare}
                    className="p-1.5 rounded-md bg-[#161a23] border border-[#222836] text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#1e2430] transition-all"
                    title="Copy Share Link"
                  >
                    {copiedLink ? <Check size={16} className="text-emerald-400" /> : <Share2 size={16} />}
                  </button>
                </div>
              </div>
            </div>

            {/* Markdown Body */}
            <div className="min-h-[500px]">
              <MarkdownViewer markdownText={activeLesson.content} />
            </div>

            {/* Pagination Controls */}
            <div className="mt-12 pt-6 border-t border-[#222836] grid grid-cols-1 sm:grid-cols-2 gap-4">
              {prevLesson ? (
                <button
                  onClick={() => setActiveLesson(prevLesson)}
                  className="p-4 rounded-xl bg-[#161a23] border border-[#222836] hover:border-[#38bdf8]/40 text-left group transition-all"
                >
                  <span className="text-[11px] text-[#64748b] uppercase font-mono font-semibold flex items-center gap-1 mb-1">
                    <ArrowLeft size={12} /> Previous Lesson
                  </span>
                  <div className="text-sm font-semibold text-[#f8fafc] group-hover:text-[#38bdf8] truncate transition-colors">
                    {prevLesson.title}
                  </div>
                </button>
              ) : (
                <div />
              )}

              {nextLesson ? (
                <button
                  onClick={() => setActiveLesson(nextLesson)}
                  className="p-4 rounded-xl bg-[#161a23] border border-[#222836] hover:border-[#38bdf8]/40 text-right group transition-all sm:col-start-2"
                >
                  <span className="text-[11px] text-[#64748b] uppercase font-mono font-semibold flex items-center justify-end gap-1 mb-1">
                    Next Lesson <ArrowRight size={12} />
                  </span>
                  <div className="text-sm font-semibold text-[#f8fafc] group-hover:text-[#38bdf8] truncate transition-colors">
                    {nextLesson.title}
                  </div>
                </button>
              ) : null}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center min-h-[400px] text-center p-8">
            <BookOpen size={48} className="text-[#38bdf8] mb-4 opacity-80" />
            <h2 className="text-xl font-bold text-[#f8fafc] mb-2">No Document Selected</h2>
            <p className="text-sm text-[#94a3b8] max-w-md">
              Choose a subject lesson from the left explorer to start reading your MSc notes.
            </p>
          </div>
        )}
      </main>

      {/* Right Table of Contents Sidebar */}
      {activeLesson && (
        <RightTOC
          headings={activeLesson.headings}
          readingTime={activeLesson.readingTime}
          isDesktopCollapsed={isTOCCollapsed}
          onToggleDesktop={() => setIsTOCCollapsed(!isTOCCollapsed)}
        />
      )}
    </div>
  );
}

