import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import CodeBlock from '../components/markdown/CodeBlock';
import { Search, Terminal, BookOpen, Layers } from 'lucide-react';

export default function ProgramsPage() {
  const { programs } = useData();
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [selectedLang, setSelectedLang] = useState('All');
  const [searchFilter, setSearchFilter] = useState('');
  const [activeProgramId, setActiveProgramId] = useState(programs[0]?.id || '');

  // Subjects & Languages lists
  const availableSubjects = ['All', ...new Set(programs.map((p) => p.subject))];
  const availableLangs = ['All', ...new Set(programs.map((p) => p.language))];

  const filteredPrograms = programs.filter((p) => {
    const matchesSubject = selectedSubject === 'All' || p.subject === selectedSubject;
    const matchesLang = selectedLang === 'All' || p.language === selectedLang;
    const matchesQuery =
      p.fileName.toLowerCase().includes(searchFilter.toLowerCase()) ||
      p.subject.toLowerCase().includes(searchFilter.toLowerCase()) ||
      p.unit.toLowerCase().includes(searchFilter.toLowerCase());
    return matchesSubject && matchesLang && matchesQuery;
  });

  const activeProgram = programs.find((p) => p.id === activeProgramId) || filteredPrograms[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 w-full">
      {/* Header Bar */}
      <div className="mb-6 pb-4 border-b border-[#222836] flex items-center justify-between gap-4 flex-col sm:flex-row">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-[#38bdf8] uppercase tracking-wider mb-1">
            <Terminal size={15} /> Code Repository
          </div>
          <h1 className="text-2xl font-bold text-[#f8fafc]">Source Code Files</h1>
          <p className="text-xs text-[#94a3b8] mt-0.5">
            Algorithms, data structures, and lab source code organized by subject.
          </p>
        </div>

        {/* Quick Search Input */}
        <div className="relative w-full sm:w-64">
          <Search size={14} className="absolute left-3 top-2.5 text-[#64748b]" />
          <input
            type="text"
            placeholder="Search programs..."
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-md bg-[#161a23] border border-[#262e3d] text-xs text-[#f8fafc] placeholder-[#64748b] focus:outline-none focus:border-[#38bdf8]"
          />
        </div>
      </div>

      {/* Dual Filter Controls: Subject & Language */}
      <div className="space-y-3 mb-6 bg-[#161a23] p-4 rounded-xl border border-[#222836]">
        {/* Subject Filter Pills */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-2">
          <span className="text-xs font-mono text-[#64748b] uppercase tracking-wider min-w-[70px] flex items-center gap-1">
            <BookOpen size={12} /> Subject:
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
            {availableSubjects.map((sub) => (
              <button
                key={sub}
                onClick={() => setSelectedSubject(sub)}
                className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-all ${
                  selectedSubject === sub
                    ? 'bg-[#38bdf8] text-[#0f1218] font-semibold shadow-xs'
                    : 'bg-[#1e2430] border border-[#2b3548] text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#252f40]'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>

        {/* Language Filter Pills */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-2 pt-2 border-t border-[#222836]">
          <span className="text-xs font-mono text-[#64748b] uppercase tracking-wider min-w-[70px] flex items-center gap-1">
            <Layers size={12} /> Language:
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
            {availableLangs.map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLang(lang)}
                className={`px-2.5 py-0.5 rounded-md text-xs font-mono capitalize whitespace-nowrap transition-all ${
                  selectedLang === lang
                    ? 'bg-[#1e293b] text-[#38bdf8] border border-[#38bdf8]/40 font-semibold'
                    : 'bg-[#12151c] border border-[#222836] text-[#64748b] hover:text-[#94a3b8]'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Grid Layout: Left Program List + Right Source Display */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Program Files List */}
        <div className="lg:col-span-4 space-y-2 max-h-[700px] overflow-y-auto pr-1">
          {filteredPrograms.length === 0 ? (
            <div className="p-8 text-center text-xs text-[#64748b] bg-[#161a23] rounded-xl border border-[#222836]">
              No programs found matching the selected subject or language filter.
            </div>
          ) : (
            filteredPrograms.map((prog) => {
              const isSelected = activeProgram && activeProgram.id === prog.id;

              return (
                <button
                  key={prog.id}
                  onClick={() => setActiveProgramId(prog.id)}
                  className={`w-full p-3 rounded-lg text-left transition-all border ${
                    isSelected
                      ? 'bg-[#1e293b] border-[#38bdf8]/50 shadow-sm'
                      : 'bg-[#161a23] border-[#222836] hover:border-[#2e374a] hover:bg-[#1a202c]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-xs font-semibold text-[#f8fafc]">{prog.fileName}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#0f1218] text-[#38bdf8] uppercase font-mono border border-[#252f42]">
                      {prog.language}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#64748b] font-mono truncate">
                    {prog.subject} &gt; {prog.unit}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Right Code Display */}
        <div className="lg:col-span-8">
          {activeProgram ? (
            <div>
              <CodeBlock
                code={activeProgram.code}
                language={activeProgram.language}
                filename={activeProgram.fileName}
              />
            </div>
          ) : (
            <div className="p-12 text-center text-xs text-[#64748b] bg-[#161a23] rounded-xl border border-[#222836]">
              Select a source code file from the left repository list to inspect logic.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

