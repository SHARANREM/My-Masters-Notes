import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import FilePreviewModal from '../components/modals/FilePreviewModal';
import { FileCheck, Search, Calendar, Download, Eye } from 'lucide-react';

export default function AssignmentsPage() {
  const { assignments } = useData();
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [searchFilter, setSearchFilter] = useState('');
  const [previewFile, setPreviewFile] = useState(null);

  const subjects = ['All', ...new Set(assignments.map((a) => a.subject))];

  const filtered = assignments.filter((a) => {
    const matchesSub = selectedSubject === 'All' || a.subject === selectedSubject;
    const matchesQuery =
      a.title.toLowerCase().includes(searchFilter.toLowerCase()) ||
      a.description.toLowerCase().includes(searchFilter.toLowerCase());
    return matchesSub && matchesQuery;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 w-full">
      {/* Title Header */}
      <div className="mb-6 pb-4 border-b border-[#222836] flex items-center justify-between gap-4 flex-col sm:flex-row">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-[#38bdf8] uppercase tracking-wider mb-1">
            <FileCheck size={15} /> Submissions & Specs
          </div>
          <h1 className="text-2xl font-bold text-[#f8fafc]">Course Assignments</h1>
          <p className="text-xs text-[#94a3b8] mt-0.5">
            Lab tasks, problem sets, specifications, and project deliverables.
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search size={14} className="absolute left-3 top-2.5 text-[#64748b]" />
          <input
            type="text"
            placeholder="Search assignments..."
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-md bg-[#161a23] border border-[#262e3d] text-xs text-[#f8fafc] placeholder-[#64748b] focus:outline-none focus:border-[#38bdf8]"
          />
        </div>
      </div>

      {/* Subject Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 scrollbar-none">
        <span className="text-xs font-mono text-[#64748b] uppercase tracking-wider mr-1">Subject:</span>
        {subjects.map((sub) => (
          <button
            key={sub}
            onClick={() => setSelectedSubject(sub)}
            className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-all ${
              selectedSubject === sub
                ? 'bg-[#38bdf8] text-[#0f1218] font-semibold shadow-xs'
                : 'bg-[#161a23] border border-[#222836] text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#1e2430]'
            }`}
          >
            {sub}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filtered.length === 0 ? (
          <div className="col-span-full p-8 text-center text-xs text-[#64748b] bg-[#161a23] rounded-xl border border-[#222836]">
            No assignments match your subject filter or search.
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              className="p-5 rounded-xl bg-[#161a23] border border-[#222836] hover:border-[#38bdf8]/40 transition-all shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <span className="text-[10px] font-mono font-semibold text-[#38bdf8] uppercase px-2 py-0.5 rounded bg-[#1e283a] border border-[#2d3a52]">
                    {item.subject}
                  </span>
                  <span
                    className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border ${
                      item.status === 'Completed'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        : item.status === 'In Progress'
                        ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        : 'bg-[#10131a] text-[#64748b] border-[#222836]'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                <h3 className="text-base font-semibold text-[#f8fafc] mb-2">{item.title}</h3>
                <p className="text-xs text-[#94a3b8] leading-relaxed mb-4">{item.description}</p>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#222836] text-xs text-[#64748b]">
                <span className="flex items-center gap-1.5 font-mono text-[11px]">
                  <Calendar size={13} className="text-[#38bdf8]" /> Due: {item.dueDate}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPreviewFile(item)}
                    className="px-3 py-1.5 rounded-md bg-[#1e2430] hover:bg-[#283244] text-xs text-[#f8fafc] font-medium transition-colors border border-[#283245] flex items-center gap-1"
                  >
                    <Eye size={13} /> View
                  </button>
                  <a
                    href={item.fileUrl}
                    download
                    className="px-3 py-1.5 rounded-md bg-[#38bdf8] hover:bg-[#60a5fa] text-xs text-[#0f1218] font-semibold flex items-center gap-1 transition-colors shadow-xs"
                  >
                    <Download size={13} /> Download
                  </a>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Embedded File Preview Modal */}
      <FilePreviewModal
        isOpen={!!previewFile}
        onClose={() => setPreviewFile(null)}
        file={previewFile}
      />
    </div>
  );
}

