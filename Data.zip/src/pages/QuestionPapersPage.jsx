import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import FilePreviewModal from '../components/modals/FilePreviewModal';
import { HelpCircle, Eye, Download, Calendar, Image as ImageIcon, FileText, Search } from 'lucide-react';

export default function QuestionPapersPage() {
  const { questionPapers } = useData();
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [selectedYear, setSelectedYear] = useState('All');
  const [searchFilter, setSearchFilter] = useState('');
  const [previewFile, setPreviewFile] = useState(null);

  const subjects = ['All', ...new Set(questionPapers.map((q) => q.subject))];
  const years = ['All', ...new Set(questionPapers.map((q) => q.year))];

  const filtered = questionPapers.filter((q) => {
    const matchesSub = selectedSubject === 'All' || q.subject === selectedSubject;
    const matchesYr = selectedYear === 'All' || q.year === selectedYear;
    const matchesQuery =
      q.title.toLowerCase().includes(searchFilter.toLowerCase()) ||
      q.subject.toLowerCase().includes(searchFilter.toLowerCase());
    return matchesSub && matchesYr && matchesQuery;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 w-full">
      {/* Title Header */}
      <div className="mb-6 pb-4 border-b border-[#222836] flex items-center justify-between gap-4 flex-col sm:flex-row">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-[#38bdf8] uppercase tracking-wider mb-1">
            <HelpCircle size={15} /> Exam Archive
          </div>
          <h1 className="text-2xl font-bold text-[#f8fafc]">Previous Question Papers</h1>
          <p className="text-xs text-[#94a3b8] mt-0.5">
            Past mid-semester tests, class quizzes, and final university question papers.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:w-56">
            <Search size={14} className="absolute left-3 top-2.5 text-[#64748b]" />
            <input
              type="text"
              placeholder="Search paper..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-md bg-[#161a23] border border-[#262e3d] text-xs text-[#f8fafc] placeholder-[#64748b] focus:outline-none focus:border-[#38bdf8]"
            />
          </div>

          {/* Year Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-[#64748b] font-mono">Year:</span>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="bg-[#161a23] border border-[#262e3d] rounded-md px-2.5 py-1.5 text-xs text-[#f8fafc] focus:outline-none focus:border-[#38bdf8]"
            >
              {years.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Subject Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 scrollbar-none">
        <span className="text-xs font-mono text-[#64748b] uppercase tracking-wider mr-1">Subject:</span>
        {subjects.map((sub) => (
          <button
            key={sub}
            onClick={() => setSelectedSubject(sub)}
            className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-all ${
              selectedSubject === sub
                ? 'bg-[#38bdf8] text-[#0f1218] font-semibold shadow-xs'
                : 'bg-[#161a23] border border-[#222836] text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#1e2430]'
            }`}
          >
            {sub}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.length === 0 ? (
          <div className="col-span-full p-8 text-center text-xs text-[#64748b] bg-[#161a23] rounded-xl border border-[#222836]">
            No question papers found matching your filters.
          </div>
        ) : (
          filtered.map((qp) => (
            <div
              key={qp.id}
              className="p-5 rounded-xl bg-[#161a23] border border-[#222836] hover:border-[#38bdf8]/40 transition-all shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono font-semibold text-[#38bdf8] uppercase px-2 py-0.5 rounded bg-[#1e283a] border border-[#2d3a52]">
                    {qp.type}
                  </span>
                  <span className="text-xs font-mono text-[#64748b] flex items-center gap-1">
                    <Calendar size={12} className="text-[#38bdf8]" /> {qp.year}
                  </span>
                </div>

                <h3 className="text-sm font-semibold text-[#f8fafc] mb-1">{qp.title}</h3>
                <span className="text-xs text-[#64748b] font-mono block mb-4">{qp.subject}</span>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#222836]">
                <span className="text-xs text-[#64748b] uppercase font-mono font-bold flex items-center gap-1">
                  {qp.format === 'image' ? <ImageIcon size={13} /> : <FileText size={13} />} {qp.format}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPreviewFile(qp)}
                    className="px-2.5 py-1.5 rounded-md bg-[#1e2430] hover:bg-[#283244] text-xs text-[#f8fafc] font-medium transition-colors border border-[#283245] flex items-center gap-1"
                  >
                    <Eye size={13} /> View
                  </button>
                  <a
                    href={qp.fileUrl}
                    download
                    className="px-2.5 py-1.5 rounded-md bg-[#38bdf8] hover:bg-[#60a5fa] text-xs text-[#0f1218] font-semibold flex items-center gap-1 transition-colors shadow-xs"
                  >
                    <Download size={13} /> Download
                  </a>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Embedded File Preview Modal */}
      <FilePreviewModal
        isOpen={!!previewFile}
        onClose={() => setPreviewFile(null)}
        file={previewFile}
      />
    </div>
  );
}

