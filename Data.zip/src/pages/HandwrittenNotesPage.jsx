import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import FilePreviewModal from '../components/modals/FilePreviewModal';
import { PenTool, Eye, Download, BookOpen, Calendar, Search, Filter } from 'lucide-react';

export default function HandwrittenNotesPage() {
  const { handwrittenNotes } = useData();
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [searchFilter, setSearchFilter] = useState('');
  const [previewFile, setPreviewFile] = useState(null);

  // Dynamic subjects list
  const subjects = ['All', ...new Set(handwrittenNotes.map((n) => n.subject))];

  const filtered = handwrittenNotes.filter((note) => {
    const matchesSubject = selectedSubject === 'All' || note.subject === selectedSubject;
    const matchesQuery =
      note.title.toLowerCase().includes(searchFilter.toLowerCase()) ||
      note.tags.some((t) => t.toLowerCase().includes(searchFilter.toLowerCase()));
    return matchesSubject && matchesQuery;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 w-full">
      {/* Header Title */}
      <div className="mb-6 pb-4 border-b border-[#222836] flex items-center justify-between gap-4 flex-col sm:flex-row">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-[#38bdf8] uppercase tracking-wider mb-1">
            <PenTool size={15} /> Digitized Scratchpads
          </div>
          <h1 className="text-2xl font-bold text-[#f8fafc]">Handwritten Lecture Notes</h1>
          <p className="text-xs text-[#94a3b8] mt-0.5">
            Classroom notebooks, mathematical derivations, and scanned board diagrams.
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search size={14} className="absolute left-3 top-2.5 text-[#64748b]" />
          <input
            type="text"
            placeholder="Search notes or #tags..."
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-md bg-[#161a23] border border-[#262e3d] text-xs text-[#f8fafc] placeholder-[#64748b] focus:outline-none focus:border-[#38bdf8]"
          />
        </div>
      </div>

      {/* Subject Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 scrollbar-none">
        <span className="text-xs font-mono text-[#64748b] uppercase tracking-wider mr-1">Subject:</span>
        {subjects.map((sub) => (
          <button
            key={sub}
            onClick={() => setSelectedSubject(sub)}
            className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-all ${
              selectedSubject === sub
                ? 'bg-[#38bdf8] text-[#0f1218] font-semibold shadow-xs'
                : 'bg-[#161a23] border border-[#222836] text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#1e2430]'
            }`}
          >
            {sub}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.length === 0 ? (
          <div className="col-span-full p-8 text-center text-xs text-[#64748b] bg-[#161a23] rounded-xl border border-[#222836]">
            No handwritten notes match the selected subject or search query.
          </div>
        ) : (
          filtered.map((note) => (
            <div
              key={note.id}
              className="p-5 rounded-xl bg-[#161a23] border border-[#222836] hover:border-[#38bdf8]/40 transition-all shadow-xs flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-[10px] font-mono font-semibold text-[#38bdf8] uppercase px-2 py-0.5 rounded bg-[#1e283a] border border-[#2d3a52]">
                    {note.subject}
                  </span>
                  <span className="text-[11px] text-[#94a3b8] font-mono flex items-center gap-1 font-semibold">
                    <BookOpen size={13} className="text-[#38bdf8]" /> {note.pages || 1} {(note.pages || 1) === 1 ? 'Page' : 'Pages'}
                  </span>
                </div>

                <h3 className="text-sm font-semibold text-[#f8fafc] mb-2 group-hover:text-[#38bdf8] transition-colors leading-snug">
                  {note.title}
                </h3>

                {/* Tags */}
                <div className="flex items-center gap-1.5 flex-wrap mb-4">
                  {note.tags.map((t) => (
                    <span
                      key={t}
                      className="text-[10px] px-2 py-0.5 rounded bg-[#10131a] text-[#808d9e] font-mono border border-[#1d222e]"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#222836] text-xs text-[#64748b]">
                <span className="flex items-center gap-1 font-mono text-[11px]">
                  <Calendar size={12} className="text-[#38bdf8]" /> {note.date}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPreviewFile(note)}
                    className="px-2.5 py-1.5 rounded-md bg-[#1e2430] hover:bg-[#283244] text-xs text-[#f8fafc] flex items-center gap-1 transition-colors font-medium border border-[#283245]"
                  >
                    <Eye size={13} /> View
                  </button>
                  <a
                    href={note.fileUrl}
                    download
                    className="px-2.5 py-1.5 rounded-md bg-[#38bdf8] hover:bg-[#60a5fa] text-xs text-[#0f1218] font-semibold flex items-center gap-1 transition-colors shadow-xs"
                  >
                    <Download size={13} />
                  </a>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Embedded File Preview Modal */}
      <FilePreviewModal
        isOpen={!!previewFile}
        onClose={() => setPreviewFile(null)}
        file={previewFile}
      />
    </div>
  );
}

