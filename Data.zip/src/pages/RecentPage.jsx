import React from 'react';
import { useData } from '../contexts/DataContext';
import { Clock, FileText, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function RecentPage() {
  const { recentHistory, contentTree, setActiveLesson } = useData();
  const navigate = useNavigate();

  const handleOpenRecent = (item) => {
    let foundLesson = null;
    contentTree.forEach((sub) => {
      sub.units.forEach((unit) => {
        unit.lessons.forEach((l) => {
          if (l.id === item.id) foundLesson = l;
        });
      });
    });

    if (foundLesson) {
      setActiveLesson(foundLesson);
      navigate('/');
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      {/* Title */}
      <div className="mb-6 pb-4 border-b border-[rgba(255,255,255,0.08)]">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#6cbcff] uppercase tracking-wider mb-1">
          <Clock size={16} /> Reading History
        </div>
        <h1 className="text-2xl font-bold text-[#f5f7fa]">Recently Viewed Lessons</h1>
      </div>

      {recentHistory.length === 0 ? (
        <div className="p-12 text-center bg-[#1d222c] rounded-2xl border border-[rgba(255,255,255,0.08)]">
          <Clock size={40} className="text-[#6cbcff] mx-auto mb-3 opacity-60" />
          <h3 className="text-base font-semibold text-[#f5f7fa] mb-1">No History Yet</h3>
          <p className="text-xs text-[#b9c0cb]">
            Lessons you open in MSc Records will appear here automatically for quick resumption.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {recentHistory.map((item, idx) => (
            <div
              key={idx}
              onClick={() => handleOpenRecent(item)}
              className="p-4 rounded-xl bg-[#1d222c] border border-[rgba(255,255,255,0.08)] hover:border-[rgba(108,188,255,0.3)] transition-all flex items-center justify-between gap-4 cursor-pointer group"
            >
              <div className="flex items-center gap-3.5 truncate">
                <div className="p-2.5 rounded-lg bg-[rgba(108,188,255,0.12)] text-[#6cbcff]">
                  <FileText size={18} />
                </div>
                <div className="truncate">
                  <h3 className="text-sm font-semibold text-[#f5f7fa] group-hover:text-[#6cbcff] transition-colors truncate">
                    {item.title}
                  </h3>
                  <span className="text-xs text-[#7d8799] font-mono">
                    {item.subjectName} &gt; {item.unitName}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs text-[#6cbcff] font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Resume Reading</span>
                <ArrowRight size={14} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
