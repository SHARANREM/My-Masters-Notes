import React from 'react';
import { useData } from '../contexts/DataContext';
import { useBookmarks } from '../contexts/BookmarkContext';
import { Bookmark, FileText, ArrowRight, Trash2, BookOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function BookmarksPage() {
  const { bookmarks, toggleBookmark } = useBookmarks();
  const { contentTree, setActiveLesson } = useData();
  const navigate = useNavigate();

  const handleOpenBookmark = (bm) => {
    // Find lesson object in contentTree
    let foundLesson = null;
    contentTree.forEach((sub) => {
      sub.units.forEach((unit) => {
        unit.lessons.forEach((l) => {
          if (l.id === bm.id) foundLesson = l;
        });
      });
    });

    if (foundLesson) {
      setActiveLesson(foundLesson);
      navigate('/');
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      {/* Title */}
      <div className="mb-6 pb-4 border-b border-[rgba(255,255,255,0.08)] flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#6cbcff] uppercase tracking-wider mb-1">
            <Bookmark size={16} /> Saved Collection
          </div>
          <h1 className="text-2xl font-bold text-[#f5f7fa]">Bookmarked Lessons</h1>
        </div>
        <span className="text-xs font-mono text-[#6cbcff] bg-[rgba(108,188,255,0.12)] px-2.5 py-1 rounded-full font-bold">
          {bookmarks.length} Saved
        </span>
      </div>

      {bookmarks.length === 0 ? (
        <div className="p-12 text-center bg-[#1d222c] rounded-2xl border border-[rgba(255,255,255,0.08)]">
          <Bookmark size={40} className="text-[#6cbcff] mx-auto mb-3 opacity-60" />
          <h3 className="text-base font-semibold text-[#f5f7fa] mb-1">No Bookmarks Saved Yet</h3>
          <p className="text-xs text-[#b9c0cb] max-w-sm mx-auto">
            Click the bookmark icon on any lesson page in MSc Records to save it here for quick access.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {bookmarks.map((bm) => (
            <div
              key={bm.id}
              className="p-4 rounded-xl bg-[#1d222c] border border-[rgba(255,255,255,0.08)] hover:border-[rgba(108,188,255,0.3)] transition-all flex items-center justify-between gap-4 group"
            >
              <div
                className="flex items-center gap-3.5 cursor-pointer flex-1 truncate"
                onClick={() => handleOpenBookmark(bm)}
              >
                <div className="p-2.5 rounded-lg bg-[rgba(108,188,255,0.12)] text-[#6cbcff]">
                  <FileText size={18} />
                </div>
                <div className="truncate">
                  <h3 className="text-sm font-semibold text-[#f5f7fa] group-hover:text-[#6cbcff] transition-colors truncate">
                    {bm.title}
                  </h3>
                  <span className="text-xs text-[#7d8799] font-mono">
                    {bm.subjectName} &gt; {bm.unitName}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenBookmark(bm)}
                  className="px-3 py-1.5 rounded-lg bg-[rgba(108,188,255,0.12)] text-[#6cbcff] hover:bg-[#6cbcff] hover:text-[#0f1115] text-xs font-semibold flex items-center gap-1 transition-all"
                >
                  Open <ArrowRight size={13} />
                </button>
                <button
                  onClick={() => toggleBookmark(bm)}
                  className="p-1.5 rounded-lg bg-[rgba(255,255,255,0.06)] hover:bg-red-500/20 text-[#7d8799] hover:text-red-400 transition-colors"
                  title="Remove Bookmark"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
