import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

export default function ComparisonTable({ content }) {
  // Parse markdown table lines inside comparison directive
  const lines = content.trim().split('\n').filter((l) => l.trim().length > 0);
  if (lines.length < 2) return <pre className="p-4 bg-[#161a23] text-xs text-[#94a3b8] rounded-lg border border-[#222836]">{content}</pre>;

  // Check if second line is divider (e.g. |---|---|)
  let rawRows = lines;
  if (lines[1].includes('---')) {
    rawRows = [lines[0], ...lines.slice(2)];
  }

  const headers = rawRows[0].split('|').map((c) => c.trim()).filter((c) => c.length > 0);
  const rows = rawRows.slice(1).map((line) =>
    line
      .split('|')
      .map((c) => c.trim())
      .filter((c, idx, arr) => (idx === 0 && c === '' ? false : idx === arr.length - 1 && c === '' ? false : true))
  );

  return (
    <div className="my-6 overflow-x-auto rounded-xl border border-[#222836] bg-[#12151c] shadow-md">
      <table className="w-full text-left text-xs sm:text-sm text-[#cbd5e1] border-collapse">
        <thead>
          <tr className="bg-[#161a23] border-b border-[#222836]">
            {headers.map((h, idx) => (
              <th key={idx} className="px-4 py-3 font-semibold text-[#38bdf8] uppercase text-xs tracking-wider">
                <ReactMarkdown
                  remarkPlugins={[remarkGfm, remarkMath]}
                  rehypePlugins={[rehypeKatex]}
                  components={{ p: ({ children }) => <span>{children}</span> }}
                >
                  {h}
                </ReactMarkdown>
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-[#1e2430]">
          {rows.map((row, rIdx) => (
            <tr key={rIdx} className="hover:bg-[#1a202c] transition-colors">
              {row.map((cell, cIdx) => (
                <td key={cIdx} className="px-4 py-3 font-normal text-[#f8fafc] leading-relaxed [&_p]:m-0">
                  <ReactMarkdown
                    remarkPlugins={[remarkGfm, remarkMath]}
                    rehypePlugins={[rehypeKatex]}
                    components={{ p: ({ children }) => <span>{children}</span> }}
                  >
                    {cell}
                  </ReactMarkdown>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

