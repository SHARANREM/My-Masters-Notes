import React from 'react';
import { ClipboardList, Calendar, ExternalLink, Download, ArrowUpRight } from 'lucide-react';

export default function AssignmentCard({ fileUrl, title, subject = 'MSC Records', dueDate }) {
  const fileName = title || fileUrl.split('/').pop().replace(/-/g, ' ').replace('.pdf', '');

  return (
    <div className="my-5 p-5 rounded-xl bg-[#1d222c] border border-[rgba(255,255,255,0.08)] hover:border-[rgba(108,188,255,0.35)] transition-all shadow-lg relative overflow-hidden group">
      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-[rgba(108,188,255,0.08)] to-transparent rounded-bl-full pointer-events-none" />

      <div className="flex items-start justify-between gap-4 mb-3">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-[rgba(108,188,255,0.15)] text-[#6cbcff]">
            <ClipboardList size={22} />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-[#6cbcff] uppercase tracking-wider block">
              Assignment Task
            </span>
            <h3 className="text-base font-semibold text-[#f5f7fa]">{fileName}</h3>
          </div>
        </div>

        {dueDate && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[rgba(255,255,255,0.06)] text-xs text-[#b9c0cb]">
            <Calendar size={13} className="text-[#6cbcff]" />
            <span>Due: {dueDate}</span>
          </div>
        )}
      </div>

      <p className="text-xs text-[#b9c0cb] mb-4 line-clamp-2">
        Formal assignment instructions, dataset files, and submission problem sets.
      </p>

      <div className="flex items-center justify-between pt-3 border-t border-[rgba(255,255,255,0.06)]">
        <span className="text-xs text-[#7d8799] font-mono">{subject}</span>
        <div className="flex items-center gap-2">
          <a
            href={fileUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-[rgba(255,255,255,0.06)] hover:bg-[rgba(255,255,255,0.12)] text-xs text-[#f5f7fa] font-medium flex items-center gap-1 transition-colors"
          >
            Open <ArrowUpRight size={13} />
          </a>
          <a
            href={fileUrl}
            download
            className="px-3 py-1.5 rounded-lg bg-[#6cbcff] hover:bg-[#89d2ff] text-xs text-[#0f1115] font-semibold flex items-center gap-1 transition-colors"
          >
            Download <Download size={13} />
          </a>
        </div>
      </div>
    </div>
  );
}
