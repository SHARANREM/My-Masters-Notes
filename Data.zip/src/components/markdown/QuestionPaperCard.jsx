import React from 'react';
import { HelpCircle, Calendar, Image as ImageIcon, Download, Eye } from 'lucide-react';

export default function QuestionPaperCard({ fileUrl, title }) {
  const fileName = title || fileUrl.split('/').pop();
  const isImage = fileUrl.endsWith('.png') || fileUrl.endsWith('.jpg') || fileUrl.endsWith('.jpeg');

  return (
    <div className="my-5 p-4 rounded-xl bg-[#1d222c] border border-[rgba(255,255,255,0.08)] hover:border-[rgba(108,188,255,0.3)] transition-all">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-[rgba(108,188,255,0.12)] text-[#6cbcff]">
            {isImage ? <ImageIcon size={20} /> : <HelpCircle size={20} />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-[#6cbcff] uppercase px-1.5 py-0.5 rounded bg-[rgba(108,188,255,0.1)]">
                Past Question Paper
              </span>
            </div>
            <h4 className="text-sm font-semibold text-[#f5f7fa] mt-1">{fileName}</h4>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={fileUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-[rgba(255,255,255,0.06)] hover:bg-[rgba(255,255,255,0.12)] text-xs text-[#f5f7fa] flex items-center gap-1.5 transition-colors"
          >
            <Eye size={13} /> View
          </a>
          <a
            href={fileUrl}
            download
            className="px-3 py-1.5 rounded-lg bg-[#6cbcff] hover:bg-[#89d2ff] text-xs text-[#0f1115] font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download size={13} /> Download
          </a>
        </div>
      </div>
    </div>
  );
}
