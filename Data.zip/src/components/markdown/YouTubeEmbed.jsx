import React from 'react';
import { Youtube } from 'lucide-react';

export default function YouTubeEmbed({ url }) {
  // Extract YouTube ID
  let videoId = '';
  if (url.includes('v=')) {
    videoId = url.split('v=')[1].split('&')[0];
  } else if (url.includes('youtu.be/')) {
    videoId = url.split('youtu.be/')[1].split('?')[0];
  } else if (url.includes('embed/')) {
    videoId = url.split('embed/')[1].split('?')[0];
  }

  if (!videoId) {
    return (
      <div className="my-5 p-4 rounded-xl bg-[#1d222c] border border-[rgba(255,255,255,0.08)] flex items-center gap-3 text-xs text-[#b9c0cb]">
        <Youtube className="text-red-400" size={20} />
        <a href={url} target="_blank" rel="noopener noreferrer" className="text-[#6cbcff] hover:underline">
          Watch on YouTube: {url}
        </a>
      </div>
    );
  }

  return (
    <div className="my-6 rounded-2xl overflow-hidden border border-[rgba(255,255,255,0.08)] bg-[#171b22] shadow-xl">
      <div className="flex items-center gap-2 px-4 py-2.5 bg-[#12151b] border-b border-[rgba(255,255,255,0.06)] text-xs text-[#b9c0cb]">
        <Youtube size={16} className="text-red-500" />
        <span className="font-medium text-[#f5f7fa]">Supplementary Video Tutorial</span>
      </div>
      <div className="relative aspect-video w-full">
        <iframe
          src={`https://www.youtube-nocookie.com/embed/${videoId}`}
          title="YouTube video player"
          className="absolute inset-0 w-full h-full border-0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    </div>
  );
}
