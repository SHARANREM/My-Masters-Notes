import React from 'react';
import { FileText, Eye, Download, ExternalLink } from 'lucide-react';

export default function PDFCard({ fileUrl, title }) {
  const fileName = title || fileUrl.split('/').pop();

  return (
    <div className="my-5 p-4 rounded-xl bg-[#1d222c] border border-[rgba(255,255,255,0.08)] hover:border-[rgba(108,188,255,0.3)] transition-all shadow-md">
      <div className="flex items-start sm:items-center justify-between gap-4 flex-col sm:flex-row">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-[rgba(108,188,255,0.12)] text-[#6cbcff]">
            <FileText size={24} />
          </div>
          <div>
            <div className="text-xs font-semibold text-[#6cbcff] uppercase tracking-wider mb-0.5">
              PDF Document
            </div>
            <h4 className="text-sm font-semibold text-[#f5f7fa] line-clamp-1">{fileName}</h4>
            <span className="text-xs text-[#b9c0cb] font-mono">{fileUrl}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end border-t sm:border-0 pt-3 sm:pt-0 border-[rgba(255,255,255,0.06)]">
          <a
            href={fileUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-[rgba(255,255,255,0.06)] hover:bg-[rgba(255,255,255,0.12)] text-xs text-[#f5f7fa] font-medium flex items-center gap-1.5 transition-colors"
          >
            <Eye size={14} /> Preview
          </a>
          <a
            href={fileUrl}
            download
            className="px-3 py-1.5 rounded-lg bg-[#6cbcff] hover:bg-[#89d2ff] text-xs text-[#0f1115] font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download size={14} /> Download
          </a>
        </div>
      </div>
    </div>
  );
}
