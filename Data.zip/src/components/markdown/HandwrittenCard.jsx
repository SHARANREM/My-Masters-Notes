import React from 'react';
import { PenTool, Eye, Download, BookOpen } from 'lucide-react';

export default function HandwrittenCard({ fileUrl, title }) {
  const fileName = title || fileUrl.split('/').pop().replace('.pdf', '');

  return (
    <div className="my-5 p-4 rounded-xl bg-[#1d222c] border border-[rgba(255,255,255,0.08)] hover:border-[rgba(108,188,255,0.3)] transition-all">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-[rgba(108,188,255,0.12)] text-[#6cbcff]">
            <PenTool size={20} />
          </div>
          <div>
            <span className="text-[10px] font-bold text-[#6cbcff] uppercase tracking-wider block">
              Handwritten Lecture Note
            </span>
            <h4 className="text-sm font-semibold text-[#f5f7fa]">{fileName}</h4>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={fileUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-[rgba(255,255,255,0.06)] hover:bg-[rgba(255,255,255,0.12)] text-xs text-[#f5f7fa] flex items-center gap-1.5 transition-colors"
          >
            <Eye size={13} /> View PDF
          </a>
          <a
            href={fileUrl}
            download
            className="px-3 py-1.5 rounded-lg bg-[#6cbcff] hover:bg-[#89d2ff] text-xs text-[#0f1115] font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download size={13} /> Download
          </a>
        </div>
      </div>
    </div>
  );
}
