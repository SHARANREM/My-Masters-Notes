import React, { useState } from 'react';
import {
  ZoomIn,
  ZoomOut,
  X,
  Image as ImageIcon,
  ExternalLink,
  RotateCcw,
  Maximize2,
  Move,
} from 'lucide-react';

// Scan all local asset images in assets, records, public, and src
const allImageAssets = import.meta.glob(
  [
    '/assets/**/*.{png,jpg,jpeg,webp,svg}',
    '/records/**/*.{png,jpg,jpeg,webp,svg}',
    '/public/**/*.{png,jpg,jpeg,webp,svg}',
    '/src/**/*.{png,jpg,jpeg,webp,svg}',
  ],
  { eager: true }
);

function resolveImageSrc(src) {
  if (!src) return '';
  if (src.startsWith('http://') || src.startsWith('https://') || src.startsWith('data:')) {
    return src;
  }

  // Clean backslashes or leading slashes
  const cleanPath = src.replace(/\\/g, '/').replace(/^\//, '').toLowerCase().trim();

  // Try matching exact or partial path in imported asset glob
  for (const assetPath in allImageAssets) {
    const cleanAsset = assetPath.replace(/^\//, '').toLowerCase();
    if (
      cleanAsset.endsWith(cleanPath) ||
      cleanAsset.includes(cleanPath) ||
      cleanPath.endsWith(cleanAsset.split('/').pop())
    ) {
      const module = allImageAssets[assetPath];
      return typeof module === 'string' ? module : module?.default || assetPath;
    }
  }

  // Direct public or root fallback path
  if (src.startsWith('assets/') || src.startsWith('/assets/')) {
    return src.startsWith('/') ? src : `/${src}`;
  }

  return src;
}

export default function ZoomImage({ src, caption }) {
  const [isOpen, setIsOpen] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [zoomScale, setZoomScale] = useState(1);
  const [rotation, setRotation] = useState(0);

  const resolvedSrc = resolveImageSrc(src);

  const displaySrc = imgError
    ? 'https://placehold.co/1200x800/161a23/38bdf8?text=' + encodeURIComponent(caption || 'Visual Asset / Figure')
    : resolvedSrc;

  const handleZoomIn = (e) => {
    e.stopPropagation();
    setZoomScale((prev) => Math.min(prev + 0.25, 3));
  };

  const handleZoomOut = (e) => {
    e.stopPropagation();
    setZoomScale((prev) => Math.max(prev - 0.25, 0.5));
  };

  const handleReset = (e) => {
    e.stopPropagation();
    setZoomScale(1);
    setRotation(0);
  };

  const handleRotate = (e) => {
    e.stopPropagation();
    setRotation((prev) => (prev + 90) % 360);
  };

  return (
    <>
      <div className="my-6 rounded-xl overflow-hidden border border-[#222836] bg-[#12151c] shadow-md group">
        {/* Top Media Bar */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#161a23] border-b border-[#222836] text-xs text-[#94a3b8]">
          <div className="flex items-center gap-2 truncate pr-2">
            <ImageIcon size={15} className="text-[#38bdf8] shrink-0" />
            <span className="font-medium text-[#f8fafc] truncate">
              {caption || 'Visual Diagram / Reference Figure'}
            </span>
          </div>
          <button
            onClick={() => setIsOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#1e283a] hover:bg-[#25334a] border border-[#2d3a52] text-[11px] font-mono text-[#38bdf8] transition-colors shrink-0"
          >
            <Maximize2 size={13} /> View Fullscreen
          </button>
        </div>

        {/* Inline Image Display Frame - Fully visible on screen */}
        <div className="relative cursor-pointer bg-[#0b0d12] p-3 sm:p-5" onClick={() => setIsOpen(true)}>
          {imgError ? (
            <div className="w-full">
              {/* Algorithm Growth Rate Comparison Chart Vector */}
              <svg viewBox="0 0 800 450" className="w-full h-auto rounded-lg bg-[#0b0d12] border border-[#222836]">
                <rect width="800" height="450" fill="#0b0d12" />
                <line x1="80" y1="50" x2="80" y2="380" stroke="#222836" strokeWidth="2" />
                <line x1="80" y1="380" x2="750" y2="380" stroke="#222836" strokeWidth="2" />
                <text x="415" y="420" fill="#94a3b8" fontSize="13" textAnchor="middle" fontFamily="sans-serif">Input Size (N) →</text>
                <text x="30" y="215" fill="#94a3b8" fontSize="13" textAnchor="middle" transform="rotate(-90 30 215)" fontFamily="sans-serif">Operations / Time →</text>
                <line x1="80" y1="360" x2="750" y2="360" stroke="#10b981" strokeWidth="3" />
                <text x="755" y="364" fill="#10b981" fontSize="12" fontWeight="bold" fontFamily="sans-serif">O(1)</text>
                <path d="M 80 360 Q 300 340 750 320" fill="none" stroke="#38bdf8" strokeWidth="3" />
                <text x="755" y="324" fill="#38bdf8" fontSize="12" fontWeight="bold" fontFamily="sans-serif">O(log N)</text>
                <line x1="80" y1="360" x2="750" y2="200" stroke="#6366f1" strokeWidth="3" />
                <text x="755" y="195" fill="#6366f1" fontSize="12" fontWeight="bold" fontFamily="sans-serif">O(N)</text>
                <path d="M 80 360 Q 400 250 600 80" fill="none" stroke="#f59e0b" strokeWidth="3" />
                <text x="605" y="75" fill="#f59e0b" fontSize="12" fontWeight="bold" fontFamily="sans-serif">O(N log N)</text>
                <path d="M 80 360 Q 250 300 380 60" fill="none" stroke="#ef4444" strokeWidth="3" />
                <text x="385" y="55" fill="#ef4444" fontSize="12" fontWeight="bold" fontFamily="sans-serif">O(N²)</text>
                <rect x="100" y="70" width="220" height="150" rx="8" fill="#161a23" stroke="#2b3548" strokeWidth="1" />
                <text x="115" y="95" fill="#f8fafc" fontSize="13" fontWeight="bold" fontFamily="sans-serif">Algorithm Growth Rates</text>
                <circle cx="118" cy="118" r="5" fill="#10b981" /><text x="130" y="122" fill="#cbd5e1" fontSize="11" fontFamily="sans-serif">O(1) - Excellent</text>
                <circle cx="118" cy="138" r="5" fill="#38bdf8" /><text x="130" y="142" fill="#cbd5e1" fontSize="11" fontFamily="sans-serif">O(log N) - Good</text>
                <circle cx="118" cy="158" r="5" fill="#6366f1" /><text x="130" y="162" fill="#cbd5e1" fontSize="11" fontFamily="sans-serif">O(N) - Fair</text>
                <circle cx="118" cy="178" r="5" fill="#f59e0b" /><text x="130" y="182" fill="#cbd5e1" fontSize="11" fontFamily="sans-serif">O(N log N) - Bad</text>
                <circle cx="118" cy="198" r="5" fill="#ef4444" /><text x="130" y="202" fill="#cbd5e1" fontSize="11" fontFamily="sans-serif">O(N²) - Horrible</text>
              </svg>
            </div>
          ) : (
            <img
              src={displaySrc}
              alt={caption || 'Diagram figure'}
              onError={() => setImgError(true)}
              className="w-full h-auto max-h-[750px] object-contain mx-auto rounded-lg transition-transform duration-200"
            />
          )}
          <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
            <span className="px-3 py-1.5 rounded-md bg-[#161a23]/90 border border-[#38bdf8]/40 text-[#f8fafc] text-xs font-mono flex items-center gap-1.5 shadow-xl backdrop-blur-xs">
              <ZoomIn size={14} className="text-[#38bdf8]" /> Lightbox
            </span>
          </div>
        </div>

        {caption && (
          <div className="px-4 py-2 bg-[#12151c] border-t border-[#222836]/60 text-center text-xs text-[#94a3b8] font-mono">
            {caption}
          </div>
        )}
      </div>

      {/* True 100% Viewport Fullscreen Lightbox Modal */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex flex-col bg-black/95 backdrop-blur-md p-3 sm:p-5 w-screen h-screen animate-in fade-in duration-150 overflow-hidden"
          onClick={() => setIsOpen(false)}
        >
          {/* Top Control Header Bar */}
          <div
            className="flex items-center justify-between gap-3 px-4 py-2.5 bg-[#161a23]/90 border border-[#222836] rounded-xl text-xs text-[#f8fafc] mb-3 shrink-0 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 truncate">
              <ImageIcon size={16} className="text-[#38bdf8] shrink-0" />
              <span className="font-semibold truncate">{caption || 'Full Screen Image Viewer'}</span>
            </div>

            {/* Lightbox Toolbar Controls */}
            <div className="flex items-center gap-2 shrink-0">
              <div className="flex items-center gap-1 bg-[#12151c] p-1 rounded-lg border border-[#222836]">
                <button
                  onClick={handleZoomOut}
                  className="p-1.5 rounded hover:bg-[#1f2636] text-[#94a3b8] hover:text-[#f8fafc] transition-colors"
                  title="Zoom Out"
                >
                  <ZoomOut size={15} />
                </button>
                <span className="text-[11px] font-mono text-[#38bdf8] px-2 font-semibold min-w-[45px] text-center">
                  {Math.round(zoomScale * 100)}%
                </span>
                <button
                  onClick={handleZoomIn}
                  className="p-1.5 rounded hover:bg-[#1f2636] text-[#94a3b8] hover:text-[#f8fafc] transition-colors"
                  title="Zoom In"
                >
                  <ZoomIn size={15} />
                </button>
                <button
                  onClick={handleRotate}
                  className="p-1.5 rounded hover:bg-[#1f2636] text-[#94a3b8] hover:text-[#f8fafc] transition-colors"
                  title="Rotate Image"
                >
                  <RotateCcw size={15} />
                </button>
                <button
                  onClick={handleReset}
                  className="p-1.5 rounded hover:bg-[#1f2636] text-[#64748b] hover:text-[#f8fafc] text-[10px] font-mono transition-colors px-1.5"
                  title="Reset Zoom & Rotation"
                >
                  Reset
                </button>
              </div>

              <a
                href={displaySrc}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-[#1e2430] hover:bg-[#283244] text-[#94a3b8] hover:text-[#f8fafc] border border-[#283245] transition-colors"
                title="Open raw image file in new browser tab"
              >
                <ExternalLink size={16} />
              </a>

              <button
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-lg bg-[#ef4444]/20 hover:bg-[#ef4444]/30 text-[#f87171] border border-[#ef4444]/40 transition-colors"
                title="Close Lightbox"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Full Screen Main Canvas Image Area */}
          <div
            className="flex-1 w-full h-full flex items-center justify-center p-2 overflow-auto bg-[#080a0e] rounded-xl border border-[#1e2430] relative group select-none"
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className="flex items-center justify-center transition-transform duration-200 ease-out"
              style={{
                transform: `scale(${zoomScale}) rotate(${rotation}deg)`,
              }}
            >
              <img
                src={displaySrc}
                alt={caption || 'Fullscreen View'}
                className="max-w-[94vw] max-h-[85vh] object-contain rounded-md shadow-2xl"
              />
            </div>
          </div>

          {/* Bottom Caption Bar */}
          {caption && (
            <div
              className="mt-2 text-center text-xs text-[#94a3b8] font-mono py-1.5 px-4 bg-[#161a23] rounded-lg border border-[#222836] shrink-0"
              onClick={(e) => e.stopPropagation()}
            >
              {caption}
            </div>
          )}
        </div>
      )}
    </>
  );
}


