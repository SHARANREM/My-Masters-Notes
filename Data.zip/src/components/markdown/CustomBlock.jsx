import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import {
  Lightbulb,
  AlertTriangle,
  AlertCircle,
  Info,
  CheckCircle2,
} from 'lucide-react';
import PDFCard from './PDFCard';
import AssignmentCard from './AssignmentCard';
import QuestionPaperCard from './QuestionPaperCard';
import HandwrittenCard from './HandwrittenCard';
import ComparisonTable from './ComparisonTable';
import FolderPreview from './FolderPreview';
import ZoomImage from './ZoomImage';
import YouTubeEmbed from './YouTubeEmbed';
import CodeBlock from './CodeBlock';
import { useData } from '../../contexts/DataContext';

export default function CustomBlock({ blockType, content }) {
  const { programs } = useData();

  const type = blockType.toLowerCase().trim();

  if (type === 'tip') {
    return (
      <div className="my-5 p-4 rounded-xl bg-[rgba(108,188,255,0.06)] border border-[rgba(108,188,255,0.25)] text-[#f5f7fa] shadow-sm">
        <div className="flex items-center gap-2 mb-2 text-[#6cbcff] font-semibold text-xs uppercase tracking-wider">
          <Lightbulb size={16} /> Tip
        </div>
        <div className="text-sm text-[#b9c0cb] leading-relaxed [&_p]:m-0">
          <ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex]}>
            {content}
          </ReactMarkdown>
        </div>
      </div>
    );
  }

  if (type === 'warning') {
    return (
      <div className="my-5 p-4 rounded-xl bg-[rgba(245,158,11,0.08)] border border-[rgba(245,158,11,0.3)] text-[#f5f7fa] shadow-sm">
        <div className="flex items-center gap-2 mb-2 text-amber-400 font-semibold text-xs uppercase tracking-wider">
          <AlertTriangle size={16} /> Warning
        </div>
        <div className="text-sm text-[#b9c0cb] leading-relaxed [&_p]:m-0">
          <ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex]}>
            {content}
          </ReactMarkdown>
        </div>
      </div>
    );
  }

  if (type === 'important') {
    return (
      <div className="my-5 p-4 rounded-xl bg-[rgba(239,68,68,0.08)] border border-[rgba(239,68,68,0.3)] text-[#f5f7fa] shadow-sm">
        <div className="flex items-center gap-2 mb-2 text-red-400 font-semibold text-xs uppercase tracking-wider">
          <AlertCircle size={16} /> Important Exam Note
        </div>
        <div className="text-sm text-[#b9c0cb] leading-relaxed [&_p]:m-0">
          <ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex]}>
            {content}
          </ReactMarkdown>
        </div>
      </div>
    );
  }

  if (type === 'note') {
    return (
      <div className="my-5 p-4 rounded-xl bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.12)] text-[#f5f7fa] shadow-sm">
        <div className="flex items-center gap-2 mb-2 text-[#b9c0cb] font-semibold text-xs uppercase tracking-wider">
          <Info size={16} /> Note
        </div>
        <div className="text-sm text-[#b9c0cb] leading-relaxed [&_p]:m-0">
          <ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex]}>
            {content}
          </ReactMarkdown>
        </div>
      </div>
    );
  }

  if (type === 'success') {
    return (
      <div className="my-5 p-4 rounded-xl bg-[rgba(16,185,129,0.08)] border border-[rgba(16,185,129,0.3)] text-[#f5f7fa] shadow-sm">
        <div className="flex items-center gap-2 mb-2 text-emerald-400 font-semibold text-xs uppercase tracking-wider">
          <CheckCircle2 size={16} /> Completed
        </div>
        <div className="text-sm text-[#b9c0cb] leading-relaxed [&_p]:m-0">
          <ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex]}>
            {content}
          </ReactMarkdown>
        </div>
      </div>
    );
  }

  if (type === 'yt') {
    return <YouTubeEmbed url={content.trim()} />;
  }

  if (type === 'pdf') {
    return <PDFCard fileUrl={content.trim()} />;
  }

  if (type === 'assignment') {
    return <AssignmentCard fileUrl={content.trim()} />;
  }

  if (type === 'questionpaper') {
    return <QuestionPaperCard fileUrl={content.trim()} />;
  }

  if (type === 'handwritten') {
    return <HandwrittenCard fileUrl={content.trim()} />;
  }

  if (type === 'compare') {
    return <ComparisonTable content={content} />;
  }

  if (type === 'folder') {
    return <FolderPreview folderPath={content.trim()} />;
  }

  if (type === 'image') {
    const parts = content.trim().split('\n');
    const src = parts[0]?.trim();
    const caption = parts.slice(1).join(' ').trim();
    return <ZoomImage src={src} caption={caption} />;
  }

  if (type === 'code') {
    const targetPath = content.trim();
    const matchedProgram = programs.find((p) => p.filePath.includes(targetPath) || p.fileName.includes(targetPath));

    if (matchedProgram) {
      return (
        <CodeBlock
          code={matchedProgram.code}
          language={matchedProgram.language}
          filename={matchedProgram.fileName}
        />
      );
    } else {
      return (
        <CodeBlock
          code={`// Reference Code File: ${targetPath}\n// Embedded file loader target.`}
          language="text"
          filename={targetPath.split('/').pop()}
        />
      );
    }
  }

  return (
    <div className="my-4 p-4 rounded-xl bg-[#1d222c] border border-[rgba(255,255,255,0.08)] text-xs text-[#b9c0cb]">
      {content}
    </div>
  );
}
