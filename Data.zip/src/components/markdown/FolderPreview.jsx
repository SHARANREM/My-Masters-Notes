import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Folder, FileCode, ArrowRight, ChevronDown, ChevronUp, Terminal, ExternalLink, Layers } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import CodeBlock from './CodeBlock';

export default function FolderPreview({ folderPath }) {
  const navigate = useNavigate();
  const { programs } = useData();
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedFileId, setSelectedFileId] = useState(null);

  const normalizedTarget = (folderPath || '').toLowerCase().trim();

  // Find all programs in this directory bundle
  const matchedPrograms = programs.filter((p) => {
    const path = (p.filePath || '').toLowerCase();
    const cleanFolder = normalizedTarget.replace(/^records\/programs\//, '').replace(/^records\//, '');
    return path.includes(normalizedTarget) || path.includes(cleanFolder);
  });

  const activeProgram = matchedPrograms.find((p) => p.id === selectedFileId) || matchedPrograms[0];

  const handleToggle = (e) => {
    e.stopPropagation();
    setIsExpanded((prev) => !prev);
  };

  const handleNavigateToPrograms = (e) => {
    e.stopPropagation();
    navigate('/programs');
  };

  return (
    <div className="my-5 rounded-xl bg-[#161a23] border border-[#222836] shadow-lg overflow-hidden transition-all hover:border-[#38bdf8]/40">
      {/* Header Bar */}
      <div
        onClick={handleToggle}
        className="p-4 bg-[#1a202c] border-b border-[#222836] flex items-center justify-between gap-4 cursor-pointer select-none group"
      >
        <div className="flex items-center gap-3 truncate">
          <div className="p-3 rounded-lg bg-[#1e283a] text-[#38bdf8] border border-[#2d3a52] shrink-0 group-hover:scale-105 transition-transform">
            <Folder size={22} />
          </div>
          <div className="truncate">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold text-[#38bdf8] uppercase tracking-wider block">
                Directory Bundle
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#0f1218] text-[#94a3b8] border border-[#222836]">
                {matchedPrograms.length} {matchedPrograms.length === 1 ? 'File' : 'Files'}
              </span>
            </div>
            <h4 className="text-sm font-semibold text-[#f8fafc] font-mono truncate mt-0.5">
              {folderPath}
            </h4>
          </div>
        </div>

        {/* Explore Files Button Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleToggle}
            className="flex items-center gap-1.5 text-xs text-[#38bdf8] font-semibold bg-[#1e283a] hover:bg-[#25334a] border border-[#2d3a52] px-3 py-1.5 rounded-lg transition-colors"
          >
            <Layers size={14} />
            <span>{isExpanded ? 'Collapse Files' : 'Explore Files'}</span>
            {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>

          <button
            type="button"
            onClick={handleNavigateToPrograms}
            className="p-2 rounded-lg bg-[#12151c] hover:bg-[#1a202c] text-[#94a3b8] hover:text-[#f8fafc] border border-[#222836] transition-colors"
            title="Open Code Repository page"
          >
            <ExternalLink size={15} />
          </button>
        </div>
      </div>

      {/* Expandable File Explorer Section */}
      {isExpanded && (
        <div className="p-4 bg-[#0f1218] border-t border-[#1e2430] animate-in fade-in duration-150">
          {matchedPrograms.length === 0 ? (
            <div className="p-6 text-center text-xs text-[#94a3b8]">
              <p className="mb-3">No source code files were found directly inside <code className="text-[#38bdf8] font-mono">{folderPath}</code>.</p>
              <button
                onClick={handleNavigateToPrograms}
                className="px-3.5 py-1.5 rounded-md bg-[#38bdf8] text-[#0f1218] text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Terminal size={14} /> View All Repository Programs <ArrowRight size={14} />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* File Selection Tabs */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none border-b border-[#1e2430]">
                {matchedPrograms.map((prog) => {
                  const isActive = activeProgram?.id === prog.id;
                  return (
                    <button
                      key={prog.id}
                      onClick={() => setSelectedFileId(prog.id)}
                      className={`px-3 py-1.5 rounded-md text-xs font-mono flex items-center gap-2 transition-all shrink-0 ${
                        isActive
                          ? 'bg-[#1e283a] text-[#38bdf8] border border-[#38bdf8]/50 font-semibold shadow-xs'
                          : 'bg-[#161a23] text-[#94a3b8] hover:text-[#f8fafc] border border-[#222836] hover:bg-[#1c222f]'
                      }`}
                    >
                      <FileCode size={14} className={isActive ? 'text-[#38bdf8]' : 'text-[#64748b]'} />
                      <span>{prog.fileName}</span>
                      <span className="text-[10px] uppercase font-bold text-[#64748b]">{prog.language}</span>
                    </button>
                  );
                })}
              </div>

              {/* Active Code Preview */}
              {activeProgram && (
                <div>
                  <CodeBlock
                    code={activeProgram.code}
                    language={activeProgram.language}
                    filename={activeProgram.fileName}
                  />
                </div>
              )}

              {/* Bottom Action Bar */}
              <div className="flex items-center justify-between pt-2 border-t border-[#1e2430] text-xs">
                <span className="text-[#64748b] font-mono">
                  Showing {matchedPrograms.length} file(s) in bundle
                </span>
                <button
                  onClick={handleNavigateToPrograms}
                  className="text-[#38bdf8] hover:underline flex items-center gap-1 font-medium"
                >
                  Open in Code Repository <ExternalLink size={13} />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

