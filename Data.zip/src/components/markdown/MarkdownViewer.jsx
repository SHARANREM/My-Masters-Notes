import React, { useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import CodeBlock from './CodeBlock';
import CustomBlock from './CustomBlock';
import ZoomImage from './ZoomImage';

export default function MarkdownViewer({ markdownText }) {
  // Parse custom directives like ::tip ... :: or ::code ... :: or ::pdf ... ::
  const parsedSections = useMemo(() => {
    if (!markdownText) return [];

    const directiveRegex = /::([a-zA-Z0-9_-]+)\s*\n([\s\S]*?)\n::/g;
    const sections = [];
    let lastIndex = 0;
    let match;

    while ((match = directiveRegex.exec(markdownText)) !== null) {
      const matchIndex = match.index;

      // Push preceding markdown text if any
      if (matchIndex > lastIndex) {
        sections.push({
          type: 'markdown',
          content: markdownText.substring(lastIndex, matchIndex),
        });
      }

      const directiveType = match[1];
      const directiveContent = match[2];

      sections.push({
        type: 'custom',
        directiveType,
        content: directiveContent,
      });

      lastIndex = directiveRegex.lastIndex;
    }

    // Push trailing markdown text
    if (lastIndex < markdownText.length) {
      sections.push({
        type: 'markdown',
        content: markdownText.substring(lastIndex),
      });
    }

    return sections;
  }, [markdownText]);

  return (
    <div className="markdown-body text-[#f5f7fa]">
      {parsedSections.map((section, idx) => {
        if (section.type === 'custom') {
          return (
            <CustomBlock
              key={idx}
              blockType={section.directiveType}
              content={section.content}
            />
          );
        }

        return (
          <ReactMarkdown
            key={idx}
            remarkPlugins={[remarkGfm, remarkMath]}
            rehypePlugins={[rehypeKatex]}
            components={{
              // Custom heading renderer to assign HTML IDs for TOC scroll linking
              h1: ({ children }) => {
                const text = React.Children.toArray(children).join('');
                const id = text.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-');
                return <h1 id={id}>{children}</h1>;
              },
              h2: ({ children }) => {
                const text = React.Children.toArray(children).join('');
                const id = text.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-');
                return <h2 id={id}>{children}</h2>;
              },
              h3: ({ children }) => {
                const text = React.Children.toArray(children).join('');
                const id = text.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-');
                return <h3 id={id}>{children}</h3>;
              },
              h4: ({ children }) => {
                const text = React.Children.toArray(children).join('');
                const id = text.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-');
                return <h4 id={id}>{children}</h4>;
              },
              code({ node, inline, className, children, ...props }) {
                const match = /language-(\w+)/.exec(className || '');
                const codeString = String(children).replace(/\n$/, '');

                if (!inline && match) {
                  return (
                    <CodeBlock
                      code={codeString}
                      language={match[1]}
                      filename={`snippet.${match[1]}`}
                    />
                  );
                }

                return (
                  <code className={className} {...props}>
                    {children}
                  </code>
                );
              },
              img({ src, alt, title }) {
                return <ZoomImage src={src} caption={alt || title} />;
              },
              table({ children }) {
                return (
                  <div className="my-6 overflow-x-auto rounded-xl border border-[#222836] bg-[#12151c] shadow-md">
                    <table className="w-full text-left border-collapse text-xs sm:text-sm text-[#cbd5e1]">{children}</table>
                  </div>
                );
              },
              th({ children }) {
                return (
                  <th className="px-4 py-3 font-semibold text-[#38bdf8] uppercase text-xs tracking-wider border-b border-[#222836] bg-[#161a23]">
                    {children}
                  </th>
                );
              },
              td({ children }) {
                return (
                  <td className="px-4 py-3 font-normal text-[#f8fafc] border-b border-[#1e2430] bg-[#12151c] leading-relaxed">
                    {children}
                  </td>
                );
              },
            }}
          >
            {section.content}
          </ReactMarkdown>
        );
      })}
    </div>
  );
}
