import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Check, WrapText, Download, Maximize2, X, Terminal } from 'lucide-react';

export default function CodeBlock({ code, language = 'javascript', filename = '' }) {
  const [copied, setCopied] = useState(false);
  const [wordWrap, setWordWrap] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || `code_snippet.${language || 'txt'}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <div className="my-5 rounded-xl border border-[rgba(255,255,255,0.08)] bg-[#171b22] overflow-hidden shadow-lg">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#12151b] border-b border-[rgba(255,255,255,0.06)] text-xs text-[#b9c0cb]">
          <div className="flex items-center gap-2 font-mono">
            <Terminal size={14} className="text-[#6cbcff]" />
            <span className="font-medium text-[#f5f7fa]">{filename || 'Snippet'}</span>
            <span className="px-2 py-0.5 rounded bg-[rgba(108,188,255,0.12)] text-[#6cbcff] uppercase text-[10px] tracking-wider font-semibold">
              {language}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setWordWrap(!wordWrap)}
              title="Toggle Word Wrap"
              className={`p-1.5 rounded hover:bg-[rgba(255,255,255,0.08)] transition-colors ${
                wordWrap ? 'text-[#6cbcff] bg-[rgba(108,188,255,0.15)]' : 'text-[#b9c0cb]'
              }`}
            >
              <WrapText size={14} />
            </button>
            <button
              onClick={handleCopy}
              title="Copy Code"
              className="p-1.5 rounded hover:bg-[rgba(255,255,255,0.08)] text-[#b9c0cb] transition-colors flex items-center gap-1"
            >
              {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              <span className="text-[11px]">{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              title="Download Code"
              className="p-1.5 rounded hover:bg-[rgba(255,255,255,0.08)] text-[#b9c0cb] transition-colors"
            >
              <Download size={14} />
            </button>
            <button
              onClick={() => setIsFullscreen(true)}
              title="Fullscreen View"
              className="p-1.5 rounded hover:bg-[rgba(255,255,255,0.08)] text-[#b9c0cb] transition-colors"
            >
              <Maximize2 size={14} />
            </button>
          </div>
        </div>

        {/* Code Content */}
        <div className="text-sm font-mono overflow-x-auto">
          <SyntaxHighlighter
            language={language}
            style={vscDarkPlus}
            showLineNumbers={true}
            wrapLongLines={wordWrap}
            customStyle={{
              margin: 0,
              padding: '1.25rem',
              backgroundColor: '#171b22',
              fontSize: '0.875rem',
              lineHeight: '1.6',
            }}
          >
            {code}
          </SyntaxHighlighter>
        </div>
      </div>

      {/* Fullscreen Modal */}
      {isFullscreen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-5xl h-[85vh] flex flex-col bg-[#171b22] border border-[rgba(255,255,255,0.12)] rounded-2xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-[#12151b] border-b border-[rgba(255,255,255,0.08)]">
              <div className="flex items-center gap-3">
                <Terminal size={18} className="text-[#6cbcff]" />
                <span className="font-semibold text-[#f5f7fa]">{filename || 'Fullscreen Viewer'}</span>
                <span className="px-2.5 py-0.5 rounded bg-[rgba(108,188,255,0.15)] text-[#6cbcff] text-xs font-semibold uppercase">
                  {language}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={handleCopy}
                  className="px-3 py-1.5 rounded-lg bg-[rgba(255,255,255,0.08)] hover:bg-[rgba(255,255,255,0.15)] text-xs text-[#f5f7fa] flex items-center gap-1.5 transition-colors"
                >
                  {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  {copied ? 'Copied' : 'Copy Code'}
                </button>
                <button
                  onClick={() => setIsFullscreen(false)}
                  className="p-1.5 rounded-lg hover:bg-[rgba(255,255,255,0.1)] text-[#b9c0cb] hover:text-[#f5f7fa]"
                >
                  <X size={20} />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4">
              <SyntaxHighlighter
                language={language}
                style={vscDarkPlus}
                showLineNumbers={true}
                wrapLongLines={wordWrap}
                customStyle={{
                  margin: 0,
                  padding: '1.5rem',
                  backgroundColor: '#171b22',
                  fontSize: '0.95rem',
                  lineHeight: '1.7',
                }}
              >
                {code}
              </SyntaxHighlighter>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
