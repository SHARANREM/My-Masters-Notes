import React, { useState } from 'react';
import {
  ChevronRight,
  ChevronDown,
  Folder,
  FolderOpen,
  FileText,
  Search,
  Filter,
  Layers,
  ChevronLeft,
  X,
} from 'lucide-react';
import { useData } from '../../contexts/DataContext';

export default function Sidebar({
  isOpen,
  onClose,
  isDesktopCollapsed = false,
  onToggleDesktop,
}) {
  const {
    contentTree,
    activeLesson,
    setActiveLesson,
    expandedFolders,
    toggleFolderExpanded,
    selectedSubjectFilter,
    setSelectedSubjectFilter,
    sidebarFilter,
    setSidebarFilter,
  } = useData();

  // Extract all available subjects
  const availableSubjects = ['All', ...contentTree.map((s) => s.name)];

  // Filter content tree based on selected subject and filter query
  const filteredTree = contentTree
    .filter((subject) => selectedSubjectFilter === 'All' || subject.name === selectedSubjectFilter)
    .map((subject) => {
      const filteredUnits = subject.units
        .map((unit) => {
          const filteredLessons = unit.lessons.filter((lesson) =>
            lesson.title.toLowerCase().includes(sidebarFilter.toLowerCase())
          );
          return { ...unit, lessons: filteredLessons };
        })
        .filter((unit) => unit.lessons.length > 0);

      return { ...subject, units: filteredUnits };
    })
    .filter((subject) => subject.units.length > 0);

  return (
    <aside
      className={`fixed lg:sticky top-14 left-0 z-30 h-[calc(100vh-3.5rem)] self-start bg-[#12151c] border-r border-[#222836] flex flex-col transition-all duration-200 ${
        isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      } ${isDesktopCollapsed ? 'lg:hidden' : 'w-72'}`}
    >
      {/* Explorer Header */}
      <div className="p-3 border-b border-[#222836] flex flex-col gap-2.5 bg-[#161a23]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-mono font-semibold text-[#38bdf8] uppercase tracking-wider">
            <Layers size={14} /> Explorer
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-[#64748b] font-mono px-1.5 py-0.5 rounded bg-[#10131a] border border-[#1f2636]">
              {contentTree.reduce((acc, s) => acc + s.units.reduce((uAcc, u) => uAcc + u.lessons.length, 0), 0)} Notes
            </span>
            {onToggleDesktop && (
              <button
                onClick={onToggleDesktop}
                className="hidden lg:flex p-1 rounded hover:bg-[#1f2636] text-[#64748b] hover:text-[#f8fafc] transition-colors"
                title="Collapse Lessons Sidebar"
              >
                <ChevronLeft size={15} />
              </button>
            )}
            <button
              onClick={onClose}
              className="lg:hidden p-1 rounded hover:bg-[#1f2636] text-[#64748b] hover:text-[#f8fafc]"
              title="Close Drawer"
            >
              <X size={15} />
            </button>
          </div>
        </div>

        {/* Quick Filter Input */}
        <div className="relative">
          <Search size={13} className="absolute left-2.5 top-2.5 text-[#64748b]" />
          <input
            type="text"
            placeholder="Filter topics..."
            value={sidebarFilter}
            onChange={(e) => setSidebarFilter(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-md bg-[#10131a] border border-[#222836] text-xs text-[#f8fafc] placeholder-[#64748b] focus:outline-none focus:border-[#38bdf8]"
          />
        </div>

        {/* Subject Filter Select */}
        <div className="flex items-center gap-1.5 text-xs text-[#94a3b8]">
          <Filter size={12} className="text-[#38bdf8]" />
          <select
            value={selectedSubjectFilter}
            onChange={(e) => setSelectedSubjectFilter(e.target.value)}
            className="w-full bg-[#10131a] border border-[#222836] rounded-md px-2 py-1 text-xs text-[#f8fafc] focus:outline-none focus:border-[#38bdf8]"
          >
            {availableSubjects.map((subject) => (
              <option key={subject} value={subject}>
                {subject}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Tree Content */}
      <div className="flex-1 overflow-y-auto p-2 text-xs select-none">
        {filteredTree.length === 0 ? (
          <div className="p-4 text-center text-[#64748b]">No matching notes found</div>
        ) : (
          filteredTree.map((subject) => {
            const isSubjectExpanded = expandedFolders[subject.id] !== false; // expanded by default

            return (
              <div key={subject.id} className="mb-1">
                {/* Subject Folder Header */}
                <button
                  onClick={() => toggleFolderExpanded(subject.id)}
                  className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded hover:bg-[#1a1f2b] text-[#f8fafc] font-semibold text-xs text-left transition-colors"
                >
                  {isSubjectExpanded ? (
                    <ChevronDown size={14} className="text-[#38bdf8]" />
                  ) : (
                    <ChevronRight size={14} className="text-[#64748b]" />
                  )}
                  {isSubjectExpanded ? (
                    <FolderOpen size={14} className="text-[#38bdf8]" />
                  ) : (
                    <Folder size={14} className="text-[#64748b]" />
                  )}
                  <span className="truncate">{subject.name}</span>
                </button>

                {/* Units under Subject */}
                {isSubjectExpanded && (
                  <div className="pl-3 mt-0.5 border-l border-[#222836] ml-2">
                    {subject.units.map((unit) => {
                      const isUnitExpanded = expandedFolders[unit.id] !== false;

                      return (
                        <div key={unit.id} className="mb-1">
                          {/* Unit Folder Header */}
                          <button
                            onClick={() => toggleFolderExpanded(unit.id)}
                            className="w-full flex items-center gap-1.5 px-2 py-1 rounded hover:bg-[#1a1f2b] text-[#94a3b8] font-medium text-xs text-left transition-colors"
                          >
                            {isUnitExpanded ? (
                              <ChevronDown size={13} className="text-[#38bdf8]" />
                            ) : (
                              <ChevronRight size={13} className="text-[#64748b]" />
                            )}
                            <Folder size={13} className={isUnitExpanded ? 'text-[#38bdf8]' : 'text-[#64748b]'} />
                            <span className="truncate">{unit.name}</span>
                          </button>

                          {/* Lessons inside Unit */}
                          {isUnitExpanded && (
                            <div className="pl-3 mt-0.5 border-l border-[#222836] ml-2 space-y-0.5">
                              {unit.lessons.map((lesson) => {
                                const isActive = activeLesson && activeLesson.id === lesson.id;

                                return (
                                  <button
                                    key={lesson.id}
                                    onClick={() => {
                                      setActiveLesson(lesson);
                                      if (window.innerWidth < 1024) onClose();
                                    }}
                                    className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-left font-sans transition-all ${
                                      isActive
                                        ? 'bg-[#1e293b] text-[#38bdf8] font-semibold border-l-2 border-[#38bdf8]'
                                        : 'text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#1a1f2b]'
                                    }`}
                                  >
                                    <FileText
                                      size={13}
                                      className={isActive ? 'text-[#38bdf8]' : 'text-[#64748b]'}
                                    />
                                    <span className="truncate">{lesson.title}</span>
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </aside>
  );
}
