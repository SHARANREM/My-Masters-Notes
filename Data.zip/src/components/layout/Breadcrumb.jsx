import React from 'react';
import { ChevronRight, Home, BookOpen, Layers, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Breadcrumb({ subject, unit, lessonTitle }) {
  return (
    <nav className="flex items-center gap-1.5 text-xs text-[#b9c0cb] py-2 px-1 overflow-x-auto whitespace-nowrap mb-4 border-b border-[rgba(255,255,255,0.06)]">
      <Link to="/" className="flex items-center gap-1 hover:text-[#6cbcff] transition-colors">
        <Home size={13} className="text-[#6cbcff]" />
        <span>Home</span>
      </Link>

      <ChevronRight size={13} className="text-[#7d8799]" />

      <span className="flex items-center gap-1 text-[#b9c0cb]">
        <BookOpen size={13} className="text-[#7d8799]" />
        <span>MSC Records</span>
      </span>

      {subject && (
        <>
          <ChevronRight size={13} className="text-[#7d8799]" />
          <span className="flex items-center gap-1 text-[#b9c0cb]">
            <Layers size={13} className="text-[#7d8799]" />
            <span>{subject}</span>
          </span>
        </>
      )}

      {unit && (
        <>
          <ChevronRight size={13} className="text-[#7d8799]" />
          <span className="text-[#b9c0cb] font-mono">{unit}</span>
        </>
      )}

      {lessonTitle && (
        <>
          <ChevronRight size={13} className="text-[#7d8799]" />
          <span className="flex items-center gap-1 text-[#6cbcff] font-semibold">
            <FileText size={13} />
            <span>{lessonTitle}</span>
          </span>
        </>
      )}
    </nav>
  );
}
