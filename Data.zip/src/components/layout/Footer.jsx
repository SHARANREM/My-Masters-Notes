import React from 'react';
import { Terminal, Shield, FolderGit2 } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="mt-16 py-8 px-6 bg-[#171b22] border-t border-[rgba(255,255,255,0.08)] text-xs text-[#b9c0cb] flex flex-col sm:flex-row items-center justify-between gap-4 select-none">
      <div className="flex items-center gap-2">
        <div className="w-5 h-5 rounded bg-[#6cbcff] flex items-center justify-center text-[#0f1115] font-black text-[10px]">
          RN
        </div>
        <span className="font-semibold text-[#f5f7fa]">Rem Notes Engine</span>
        <span className="text-[#7d8799]">| Personal MSc & CS Study Documentation Hub</span>
      </div>

      <div className="flex items-center gap-6 text-[#7d8799]">
        <span className="flex items-center gap-1">
          <Terminal size={13} className="text-[#6cbcff]" /> Local Files Indexed
        </span>
        <span className="flex items-center gap-1">
          <Shield size={13} className="text-emerald-400" /> Private & Client-Only
        </span>
      </div>
    </footer>
  );
}
