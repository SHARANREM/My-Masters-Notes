import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  BookOpen,
  Code2,
  FileCheck,
  HelpCircle,
  PenTool,
  Bookmark,
  Clock,
  Search,
  Menu,
  X,
  Compass,
  Sun,
  Moon,
} from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import { useBookmarks } from '../../contexts/BookmarkContext';

export default function Header({ isMobileOpen, setIsMobileOpen }) {
  const { setIsSearchOpen, theme, toggleTheme } = useData();
  const { bookmarks } = useBookmarks();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'MSC Records', icon: BookOpen },
    { path: '/programs', label: 'Programs', icon: Code2 },
    { path: '/assignments', label: 'Assignments', icon: FileCheck },
    { path: '/question-papers', label: 'Question Papers', icon: HelpCircle },
    { path: '/handwritten-notes', label: 'Handwritten Notes', icon: PenTool },
    { path: '/bookmarks', label: 'Bookmarks', icon: Bookmark, badge: bookmarks.length },
    { path: '/recent', label: 'Recent', icon: Clock },
  ];

  const handleMobileNavClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#12151c]/95 backdrop-blur-md border-b border-[#222836] flex flex-col justify-center px-4 sm:px-6 select-none transition-all">
      <div className="h-14 flex items-center justify-between">
        {/* Left Branding & Mobile Trigger */}
        <div className="flex items-center gap-3">
          {/* Mobile top nav toggle button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-md text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#1e2433] border border-transparent hover:border-[#2b3548] transition-all"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>

          {/* Sidebar drawer trigger for MSC Records view on mobile */}
          {location.pathname === '/' && (
            <button
              onClick={() => setIsMobileOpen(!isMobileOpen)}
              className="lg:hidden p-2 rounded-md text-[#38bdf8] bg-[#1e283a] border border-[#2d3a52] hover:bg-[#25334a] transition-all flex items-center gap-1.5 text-xs font-mono"
              title="Toggle Lesson Sidebar"
            >
              <Compass size={15} />
              <span className="hidden sm:inline">Lessons</span>
            </button>
          )}

          <NavLink to="/" className="flex items-center gap-2.5 group">
            
            <div className="flex flex-col">
              <span className="font-semibold text-sm text-[#f8fafc] tracking-tight group-hover:text-[#38bdf8] transition-colors">
                Notes
              </span>
            </div>
          </NavLink>
        </div>

        {/* Center Navigation Tabs (Desktop & Laptop) */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-all relative ${
                    isActive
                      ? 'bg-[#1e293b] text-[#38bdf8] border border-[#334155] shadow-xs'
                      : 'text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#181d28]'
                  }`
                }
              >
                <Icon size={14} className="opacity-90" />
                <span>{item.label}</span>
                {item.badge > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-[#38bdf8]/15 text-[#38bdf8] text-[10px] font-mono font-semibold border border-[#38bdf8]/30">
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Right Quick Actions */}
        <div className="flex items-center gap-2">
          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-md bg-[#181c26] border border-[#262e40] text-xs text-[#94a3b8] hover:border-[#38bdf8]/40 hover:text-[#f8fafc] transition-all flex items-center gap-1.5"
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <>
                <Sun size={15} className="text-amber-400" />
                <span className="hidden sm:inline font-mono font-medium text-xs">Light</span>
              </>
            ) : (
              <>
                <Moon size={15} className="text-[#0284c7]" />
                <span className="hidden sm:inline font-mono font-medium text-xs">Dark</span>
              </>
            )}
          </button>

          <button
            onClick={() => setIsSearchOpen(true)}
            className="flex items-center gap-2.5 px-2.5 py-1.5 rounded-md bg-[#181c26] border border-[#262e40] text-xs text-[#94a3b8] hover:border-[#38bdf8]/40 hover:text-[#f8fafc] transition-all"
          >
            <Search size={14} className="text-[#38bdf8]" />
            <span className="hidden sm:inline font-mono">Search notes...</span>
            <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] bg-[#0f121a] border border-[#222938] rounded text-[#64748b] font-mono">
              ⌘K
            </kbd>
          </button>
        </div>
      </div>

      {/* Mobile Top Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#222836] py-3 bg-[#12151c] animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="text-[11px] font-mono font-semibold uppercase tracking-wider text-[#64748b] px-2 mb-2">
            Navigation Menu
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={handleMobileNavClick}
                  className={({ isActive }) =>
                    `px-3 py-2 rounded-md text-xs font-medium flex items-center justify-between transition-all ${
                      isActive
                        ? 'bg-[#1e293b] text-[#38bdf8] border border-[#334155]'
                        : 'text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#1a1e2b] border border-transparent'
                    }`
                  }
                >
                  <div className="flex items-center gap-2.5">
                    <Icon size={15} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-[#38bdf8]/15 text-[#38bdf8] text-[10px] font-mono font-bold">
                      {item.badge}
                    </span>
                  )}
                </NavLink>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
}

