import React, { useState, useEffect } from 'react';
import { List, Clock, ChevronRight } from 'lucide-react';

export default function RightTOC({
  headings = [],
  readingTime = 1,
  isDesktopCollapsed = false,
  onToggleDesktop,
}) {
  const [activeHeadingId, setActiveHeadingId] = useState('');
  const [scrollProgress, setScrollProgress] = useState(0);

  // Track scroll position for reading progress bar & heading highlight
  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        const currentProgress = Math.min(100, Math.max(0, (window.scrollY / totalHeight) * 100));
        setScrollProgress(Math.round(currentProgress));
      }

      // Highlight heading closest to top
      const headingElements = headings.map((h) => document.getElementById(h.id)).filter(Boolean);
      for (let i = headingElements.length - 1; i >= 0; i--) {
        const rect = headingElements[i].getBoundingClientRect();
        if (rect.top <= 120) {
          setActiveHeadingId(headingElements[i].id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [headings]);

  const scrollToHeading = (id) => {
    const elem = document.getElementById(id);
    if (elem) {
      const yOffset = -80; // Header offset
      const y = elem.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <aside
      className={`hidden xl:block w-64 sticky top-14 h-[calc(100vh-3.5rem)] self-start bg-[#12151c] border-l border-[#222836] p-4 overflow-y-auto select-none transition-all duration-200 ${
        isDesktopCollapsed ? 'xl:hidden' : ''
      }`}
    >
      {/* Header Info */}
      <div className="mb-4 pb-3 border-b border-[#222836] flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-mono font-semibold text-[#38bdf8] uppercase tracking-wider">
            <List size={14} /> On This Page
          </div>
          {onToggleDesktop && (
            <button
              onClick={onToggleDesktop}
              className="p-1 rounded hover:bg-[#1f2636] text-[#64748b] hover:text-[#f8fafc] transition-colors"
              title="Collapse On This Page panel"
            >
              <ChevronRight size={15} />
            </button>
          )}
        </div>

        {/* Reading Metrics */}
        <div className="flex items-center justify-between text-xs text-[#94a3b8] bg-[#161a23] px-2.5 py-1.5 rounded-md border border-[#222836]">
          <div className="flex items-center gap-1.5 font-mono">
            <Clock size={13} className="text-[#38bdf8]" />
            <span>{readingTime} min read</span>
          </div>
          <span className="font-mono text-[#38bdf8] font-semibold">{scrollProgress}%</span>
        </div>

        {/* Scroll Progress Bar */}
        <div className="w-full h-1 bg-[#161a23] rounded-full overflow-hidden mt-0.5 border border-[#222836]">
          <div
            className="h-full bg-[#38bdf8] transition-all duration-150"
            style={{ width: `${scrollProgress}%` }}
          />
        </div>
      </div>

      {/* Headings List */}
      <div className="space-y-1 text-xs">
        {headings.length === 0 ? (
          <p className="text-[#64748b] font-mono italic text-center py-4">No sections detected</p>
        ) : (
          headings.map((heading, idx) => {
            const isActive = activeHeadingId === heading.id;
            const indentClass =
              heading.level === 1
                ? 'font-semibold text-[#f8fafc]'
                : heading.level === 2
                ? 'pl-2 text-[#94a3b8]'
                : 'pl-4 text-[#64748b]';

            return (
              <button
                key={idx}
                onClick={() => scrollToHeading(heading.id)}
                className={`w-full text-left py-1 px-2 rounded-md transition-all truncate block ${indentClass} ${
                  isActive
                    ? 'bg-[#1e293b] text-[#38bdf8] font-semibold border-l-2 border-[#38bdf8]'
                    : 'hover:text-[#f8fafc] hover:bg-[#161a23]'
                }`}
              >
                {heading.title}
              </button>
            );
          })
        )}
      </div>
    </aside>
  );
}

