import React, { useState } from 'react';
import {
  X,
  Download,
  ExternalLink,
  FileText,
  Image as ImageIcon,
  AlertCircle,
  Maximize2,
  BookOpen,
} from 'lucide-react';

export default function FilePreviewModal({ isOpen, onClose, file }) {
  const [iframeError, setIframeError] = useState(false);

  if (!isOpen || !file) return null;

  const isImage =
    file.format === 'image' ||
    /\.(png|jpe?g|webp|gif|svg)$/i.test(file.fileUrl || '') ||
    /\.(png|jpe?g|webp|gif|svg)$/i.test(file.fileName || '');

  const pageCount = file.pages || file.pageCount || (isImage ? 1 : null);

  const handleDownload = async () => {
    if (!file.fileUrl) return;
    try {
      const response = await fetch(file.fileUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const ext = isImage ? 'jpg' : 'pdf';
      const cleanName = (file.title || 'document').replace(/[^a-zA-Z0-9-_ ]/g, '');
      link.download = `${cleanName}.${ext}`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    } catch {
      // Fallback direct link download
      const link = document.createElement('a');
      link.href = file.fileUrl;
      link.download = file.title || 'download';
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="relative w-full max-w-5xl h-[88vh] bg-[#12151c] border border-[#283245] rounded-xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="px-4 sm:px-5 py-3 border-b border-[#222836] bg-[#161a23] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 truncate">
            <div className="p-2 rounded-md bg-[#1e283a] text-[#38bdf8] border border-[#2d3a52] shrink-0">
              {isImage ? <ImageIcon size={18} /> : <FileText size={18} />}
            </div>
            <div className="truncate">
              <h3 className="text-sm font-semibold text-[#f8fafc] truncate">
                {file.title || file.fileName}
              </h3>
              <p className="text-[11px] text-[#64748b] font-mono truncate flex items-center gap-2">
                <span>{file.subject || 'Document'}</span>
                {file.unit && <span>• {file.unit}</span>}
                {pageCount && (
                  <span className="text-[#38bdf8] flex items-center gap-1 font-semibold">
                    <BookOpen size={12} /> {pageCount} {pageCount === 1 ? 'Page' : 'Pages'}
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleDownload}
              className="px-3 py-1.5 rounded-md bg-[#38bdf8] hover:bg-[#60a5fa] text-[#0f1218] text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
            >
              <Download size={14} /> Download
            </button>
            <a
              href={file.fileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-md bg-[#1e283a] hover:bg-[#25334a] text-[#38bdf8] border border-[#2d3a52] text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Open full PDF/Image in new window"
            >
              <ExternalLink size={14} /> Open Full
            </a>
            <button
              onClick={onClose}
              className="p-1.5 rounded-md bg-[#1e2430] hover:bg-[#283244] text-[#94a3b8] hover:text-[#f8fafc] border border-[#283245] transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Modal Content / Preview Area */}
        <div className="flex-1 bg-[#0b0d12] flex items-center justify-center p-2 sm:p-4 overflow-auto relative">
          {isImage ? (
            <div className="w-full h-full flex flex-col items-center justify-center overflow-auto p-2">
              <img
                src={file.fileUrl}
                alt={file.title}
                className="max-w-full max-h-[72vh] object-contain rounded-md shadow-xl border border-[#1e2430]"
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = 'https://placehold.co/900x600/161a23/38bdf8?text=Image+Document+Preview';
                }}
              />
            </div>
          ) : (
            <object
              data={`${file.fileUrl}#toolbar=1&navpanes=0`}
              type="application/pdf"
              className="w-full h-full rounded-md border border-[#1e2430] bg-[#12151c]"
            >
              {/* Chrome PDF Iframe Blocked Fallback UI */}
              <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center bg-[#12151c] rounded-md border border-[#222836]">
                <div className="p-3 rounded-full bg-[#1e283a] text-[#38bdf8] mb-4 border border-[#2d3a52]">
                  <AlertCircle size={32} />
                </div>
                <h3 className="text-base font-semibold text-[#f8fafc] mb-1">
                  Chrome PDF Viewer Restriction
                </h3>
                <p className="text-xs text-[#94a3b8] max-w-md mb-6 leading-relaxed">
                  Chrome security policies restrict embedding PDF plugins inside nested iframe containers. You can instantly view or download the complete PDF document below.
                </p>

                <div className="flex items-center gap-3">
                  <a
                    href={file.fileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-md bg-[#38bdf8] hover:bg-[#60a5fa] text-[#0f1218] text-xs font-semibold flex items-center gap-2 shadow-md transition-all"
                  >
                    <ExternalLink size={15} /> Open PDF in Full Window
                  </a>
                  <button
                    onClick={handleDownload}
                    className="px-4 py-2 rounded-md bg-[#161a23] hover:bg-[#1e2430] text-[#f8fafc] border border-[#262e3d] text-xs font-medium flex items-center gap-2 transition-all"
                  >
                    <Download size={15} /> Save PDF File
                  </button>
                </div>
              </div>
            </object>
          )}
        </div>
      </div>
    </div>
  );
}

