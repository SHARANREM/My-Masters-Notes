import React, { useState, useEffect, useMemo, useRef } from 'react';
import Fuse from 'fuse.js';
import { Search, X, FileText, Code2, BookOpen, Clock, ArrowRight } from 'lucide-react';
import { useData } from '../../contexts/DataContext';

export default function SearchModal({ isOpen, onClose }) {
  const { contentTree, programs, setActiveLesson } = useData();
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef(null);

  // Flatten lessons into searchable items
  const searchableItems = useMemo(() => {
    const items = [];

    contentTree.forEach((subject) => {
      subject.units.forEach((unit) => {
        unit.lessons.forEach((lesson) => {
          items.push({
            id: lesson.id,
            title: lesson.title,
            subject: subject.name,
            unit: unit.name,
            type: 'Lesson',
            content: lesson.content,
            lessonObj: lesson,
          });
        });
      });
    });

    programs.forEach((prog) => {
      items.push({
        id: prog.id,
        title: prog.fileName,
        subject: prog.subject,
        unit: prog.unit,
        type: 'Program Code',
        content: prog.code,
        programObj: prog,
      });
    });

    return items;
  }, [contentTree, programs]);

  // Configure Fuse.js fuzzy search
  const fuse = useMemo(() => {
    return new Fuse(searchableItems, {
      keys: ['title', 'subject', 'unit', 'type', 'content'],
      threshold: 0.35,
      includeMatches: true,
    });
  }, [searchableItems]);

  const results = useMemo(() => {
    if (!query.trim()) return searchableItems.slice(0, 8);
    return fuse.search(query).map((res) => res.item).slice(0, 10);
  }, [query, fuse, searchableItems]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(1, results.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + results.length) % Math.max(1, results.length));
    } else if (e.key === 'Enter' && results.length > 0) {
      e.preventDefault();
      const selected = results[selectedIndex];
      if (selected) {
        if (selected.lessonObj) {
          setActiveLesson(selected.lessonObj);
        }
        onClose();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/80 backdrop-blur-md animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-[#171b22] border border-[rgba(255,255,255,0.12)] rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search Header Input */}
        <div className="flex items-center gap-3 px-4 py-3 bg-[#12151b] border-b border-[rgba(255,255,255,0.08)]">
          <Search size={18} className="text-[#6cbcff]" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search subjects, lessons, code, formulas..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            className="w-full bg-transparent text-sm text-[#f5f7fa] placeholder-[#7d8799] focus:outline-none font-sans"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-[rgba(255,255,255,0.08)] text-[#b9c0cb] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-2">
          {results.length === 0 ? (
            <div className="p-8 text-center text-xs text-[#7d8799]">
              No documents or code found matching "{query}"
            </div>
          ) : (
            results.map((item, idx) => {
              const isSelected = idx === selectedIndex;
              const isCode = item.type === 'Program Code';

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    if (item.lessonObj) setActiveLesson(item.lessonObj);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`w-full flex items-center justify-between p-3 rounded-xl text-left transition-all mb-1 ${
                    isSelected
                      ? 'bg-[rgba(108,188,255,0.15)] border border-[rgba(108,188,255,0.3)] text-[#f5f7fa]'
                      : 'hover:bg-[#1d222c] text-[#b9c0cb]'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate">
                    <div className="p-2 rounded-lg bg-[#12151b] text-[#6cbcff]">
                      {isCode ? <Code2 size={16} /> : <FileText size={16} />}
                    </div>
                    <div className="truncate">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-[#f5f7fa] truncate">{item.title}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-[rgba(108,188,255,0.12)] text-[#6cbcff] uppercase font-mono">
                          {item.type}
                        </span>
                      </div>
                      <span className="text-[11px] text-[#7d8799] font-mono">
                        {item.subject} &gt; {item.unit}
                      </span>
                    </div>
                  </div>

                  <ArrowRight size={14} className={isSelected ? 'text-[#6cbcff]' : 'text-transparent'} />
                </button>
              );
            })
          )}
        </div>

        {/* Modal Footer Help */}
        <div className="px-4 py-2 bg-[#12151b] border-t border-[rgba(255,255,255,0.06)] flex items-center justify-between text-[11px] text-[#7d8799] font-mono">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>ESC Close</span>
          </div>
          <span>Rem Notes Instant Search</span>
        </div>
      </div>
    </div>
  );
}
