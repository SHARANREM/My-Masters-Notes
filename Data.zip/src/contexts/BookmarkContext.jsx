import React, { createContext, useContext, useState, useEffect } from 'react';
import { getBookmarks, toggleBookmark, isBookmarked } from '../utils/storage';

const BookmarkContext = createContext(null);

export function BookmarkProvider({ children }) {
  const [bookmarks, setBookmarks] = useState([]);

  useEffect(() => {
    setBookmarks(getBookmarks());
  }, []);

  const handleToggleBookmark = (lesson) => {
    const updated = toggleBookmark(lesson);
    setBookmarks(updated);
  };

  const checkIfBookmarked = (lessonId) => {
    return bookmarks.some((b) => b.id === lessonId);
  };

  return (
    <BookmarkContext.Provider
      value={{
        bookmarks,
        toggleBookmark: handleToggleBookmark,
        isBookmarked: checkIfBookmarked,
      }}
    >
      {children}
    </BookmarkContext.Provider>
  );
}

export function useBookmarks() {
  const context = useContext(BookmarkContext);
  if (!context) throw new Error('useBookmarks must be used within BookmarkProvider');
  return context;
}
