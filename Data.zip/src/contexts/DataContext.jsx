import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  buildContentTree,
  buildProgramsList,
  buildAssignmentsList,
  buildQuestionPapersList,
  buildHandwrittenNotesList,
} from '../utils/contentIndexer';
import {
  getRecentHistory,
  addRecentItem,
  getExpandedFolders,
  saveExpandedFolders,
} from '../utils/storage';

const DataContext = createContext(null);

export function DataProvider({ children }) {
  const [contentTree, setContentTree] = useState([]);
  const [programs, setPrograms] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [questionPapers, setQuestionPapers] = useState([]);
  const [handwrittenNotes, setHandwrittenNotes] = useState([]);
  const [activeLesson, setActiveLesson] = useState(null);
  const [recentHistory, setRecentHistory] = useState([]);
  const [expandedFolders, setExpandedFolders] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState('All');
  const [sidebarFilter, setSidebarFilter] = useState('');

  // Scroll memory store for lessons: { [lessonId]: scrollY }
  const lessonScrollPositionsRef = useRef({});
  const lastActiveLessonIdRef = useRef(null);

  // Theme State ('dark' | 'light') with localStorage persistence
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('rem_notes_theme') || 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('rem_notes_theme', theme);
    } catch (e) {
      console.error(e);
    }
    if (theme === 'light') {
      document.documentElement.classList.add('light-theme');
    } else {
      document.documentElement.classList.remove('light-theme');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Initial loading of local content index
  useEffect(() => {
    const tree = buildContentTree();
    setContentTree(tree);
    setPrograms(buildProgramsList());
    setAssignments(buildAssignmentsList());
    setQuestionPapers(buildQuestionPapersList());
    setHandwrittenNotes(buildHandwrittenNotesList());
    setRecentHistory(getRecentHistory());
    setExpandedFolders(getExpandedFolders());

    // Set initial active lesson if available
    if (tree.length > 0 && tree[0].units.length > 0 && tree[0].units[0].lessons.length > 0) {
      setActiveLesson(tree[0].units[0].lessons[0]);
    }
  }, []);

  const handleSelectLesson = (lesson) => {
    setActiveLesson(lesson);
    const updated = addRecentItem(lesson);
    setRecentHistory(updated);
  };

  const toggleFolderExpanded = (folderId) => {
    setExpandedFolders((prev) => {
      const next = { ...prev, [folderId]: !prev[folderId] };
      saveExpandedFolders(next);
      return next;
    });
  };

  // Shortcut key listener for Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <DataContext.Provider
      value={{
        contentTree,
        programs,
        assignments,
        questionPapers,
        handwrittenNotes,
        activeLesson,
        setActiveLesson: handleSelectLesson,
        recentHistory,
        expandedFolders,
        toggleFolderExpanded,
        searchQuery,
        setSearchQuery,
        isSearchOpen,
        setIsSearchOpen,
        selectedSubjectFilter,
        setSelectedSubjectFilter,
        sidebarFilter,
        setSidebarFilter,
        theme,
        setTheme,
        toggleTheme,
        lessonScrollPositionsRef,
        lastActiveLessonIdRef,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within DataProvider');
  return context;
}
