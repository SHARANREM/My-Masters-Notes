/**
 * Rem Notes Content Indexer
 * Scans local folder hierarchy using Vite's import.meta.glob
 * Generates dynamic JSON tree for Subjects, Units, Lessons, Programs, Assignments, and Question Papers.
 */

// Glob imports for records, programs, and document assets
const markdownFiles = import.meta.glob('/records/MSC Records/**/*.md', { query: '?raw', eager: true });
const programFiles = import.meta.glob('/records/Programs/**/*.*', { query: '?raw', eager: true });
const documentAssetFiles = import.meta.glob(['/records/**/*.{pdf,png,jpg,jpeg,webp,svg}', '/public/**/*.{pdf,png,jpg,jpeg,webp,svg}'], { eager: true, query: '?url' });

// Parse Markdown frontmatter/headings metadata helper
export function extractHeadings(markdownText) {
  if (!markdownText) return [];
  const headingRegex = /^(#{1,4})\s+(.+)$/gm;
  const headings = [];
  let match;

  while ((match = headingRegex.exec(markdownText)) !== null) {
    const level = match[1].length;
    const title = match[2].trim();
    const id = title.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-');
    headings.push({ level, title, id });
  }

  return headings;
}

// Calculate estimated reading time
export function calculateReadingTime(text) {
  if (!text) return 1;
  const words = text.trim().split(/\s+/).length;
  return Math.max(1, Math.ceil(words / 200));
}

// Main function to parse and structure all MSc Records from folder paths
export function buildContentTree() {
  const subjectsMap = new Map();

  Object.keys(markdownFiles).forEach((filePath) => {
    // Expected path: /records/MSC Records/Subject/Unit-X/Lesson.md
    const relativePath = filePath.replace('/records/MSC Records/', '');
    const parts = relativePath.split('/');

    if (parts.length >= 3) {
      const subjectName = parts[0];
      const unitName = parts[1];
      const fileName = parts[2];

      const rawContent = markdownFiles[filePath]?.default || markdownFiles[filePath] || '';
      const cleanTitle = fileName
        .replace(/^\d+-/, '')
        .replace(/\.md$/, '')
        .replace(/-/g, ' ');

      const lessonId = `${subjectName}_${unitName}_${fileName}`
        .toLowerCase()
        .replace(/[^\w]/g, '_');

      const headings = extractHeadings(rawContent);
      const readingTime = calculateReadingTime(rawContent);

      if (!subjectsMap.has(subjectName)) {
        subjectsMap.set(subjectName, {
          name: subjectName,
          id: subjectName.toLowerCase().replace(/[^\w]/g, '_'),
          units: new Map(),
        });
      }

      const subjectObj = subjectsMap.get(subjectName);

      if (!subjectObj.units.has(unitName)) {
        subjectObj.units.set(unitName, {
          name: unitName,
          id: `${subjectName}_${unitName}`.toLowerCase().replace(/[^\w]/g, '_'),
          lessons: [],
        });
      }

      subjectObj.units.get(unitName).lessons.push({
        id: lessonId,
        title: cleanTitle,
        fileName,
        filePath,
        content: rawContent,
        headings,
        readingTime,
        subjectName,
        unitName,
      });
    }
  });

  // Convert Maps to Arrays and sort
  const subjects = Array.from(subjectsMap.values()).map((subject) => ({
    ...subject,
    units: Array.from(subject.units.values()).map((unit) => ({
      ...unit,
      lessons: unit.lessons.sort((a, b) => a.fileName.localeCompare(b.fileName)),
    })).sort((a, b) => a.name.localeCompare(b.name)),
  }));

  return subjects;
}

// Function to index all Programs
export function buildProgramsList() {
  const programs = [];

  Object.keys(programFiles).forEach((filePath) => {
    // Expected path: /records/Programs/Subject/Unit-X/FileName.ext
    const relativePath = filePath.replace('/records/Programs/', '');
    const parts = relativePath.split('/');

    if (parts.length >= 2) {
      const subject = parts[0];
      const unit = parts.length > 2 ? parts[1] : 'General';
      const fileName = parts[parts.length - 1];
      const ext = fileName.split('.').pop().toLowerCase();
      const codeContent = programFiles[filePath]?.default || programFiles[filePath] || '';

      const languageMap = {
        py: 'python',
        java: 'java',
        cpp: 'cpp',
        c: 'c',
        js: 'javascript',
        sql: 'sql',
        html: 'html',
        css: 'css',
        json: 'json',
        xml: 'xml',
      };

      programs.push({
        id: filePath.toLowerCase().replace(/[^\w]/g, '_'),
        filePath,
        fileName,
        subject,
        unit,
        extension: ext,
        language: languageMap[ext] || 'text',
        code: codeContent,
      });
    }
  });

  return programs;
}

// Dataset for Assignments, Question Papers, and Handwritten Notes with local folder discovery
export function buildAssignmentsList() {
  const defaultList = [
    {
      id: 'asgn_adsa_1',
      title: 'Assignment 1: Asymptotic Analysis & Recurrences',
      subject: 'Advanced Data Structures',
      unit: 'Unit 1',
      dueDate: '2026-08-15',
      status: 'In Progress',
      fileUrl: '/records/Assignments/ADSA/Assignment-1.pdf',
      description: 'Solve recurrence trees for Master Theorem edge cases and analyze Space-Time tradeoffs for multi-dimensional dynamic programming.',
    },
    {
      id: 'asgn_adsa_2',
      title: 'Assignment 2: Self-Balancing Trees & B-Tree Indexing',
      subject: 'Advanced Data Structures',
      unit: 'Unit 2',
      dueDate: '2026-08-28',
      status: 'Pending',
      fileUrl: '/records/Assignments/ADSA/Assignment-2.pdf',
      description: 'Implement AVL Tree rotation balancing and evaluate disk block page fetches for B-Tree order 5.',
    },
    {
      id: 'asgn_ml_1',
      title: 'Assignment 1: Regression & Gradient Descent Optimization',
      subject: 'Machine Learning & AI',
      unit: 'Unit 1',
      dueDate: '2026-08-20',
      status: 'Completed',
      fileUrl: '/records/Assignments/ML_AI/Assignment-1-Regression.pdf',
      description: 'Derive loss functions for Ridge & Lasso regularization and simulate SGD with Adam optimizer.',
    },
    {
      id: 'asgn_ds_1',
      title: 'Assignment 1: Raft Consensus Protocol Simulation',
      subject: 'Distributed Systems',
      unit: 'Unit 1',
      dueDate: '2026-09-02',
      status: 'Pending',
      fileUrl: '/records/Assignments/Distributed_Systems/Assignment-1-Raft.pdf',
      description: 'Analyze leader election heartbeat timers, log replication safety, and partition recovery in Raft.',
    },
  ];

  // Dynamically scan any local files in /records/Assignments or containing assignment
  const dynamicItems = [];
  Object.keys(documentAssetFiles).forEach((path) => {
    if (path.toLowerCase().includes('assignment')) {
      const parts = path.split('/');
      const fileName = parts[parts.length - 1];
      const rawSubject = parts.length > 3 ? parts[parts.length - 2] : 'MSc Computer Science';
      const subject = rawSubject === 'Assignments' ? 'MSc Computer Science' : rawSubject;

      let cleanTitle = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      if (cleanTitle.toLowerCase().includes('mcr-sy old')) {
        cleanTitle = 'MCR-SY Syllabus & Old Assignment Archive';
      } else if (cleanTitle.toLowerCase().includes('msc syllabus sem-1')) {
        cleanTitle = 'MSc Computer Science Syllabus & Specs (Sem-1)';
      }

      const resolvedUrl = typeof documentAssetFiles[path] === 'string' 
        ? documentAssetFiles[path] 
        : (documentAssetFiles[path]?.default || path);

      dynamicItems.push({
        id: path.toLowerCase().replace(/[^\w]/g, '_'),
        title: cleanTitle,
        subject: subject,
        unit: 'Local Document',
        dueDate: 'Active Term',
        status: 'In Progress',
        fileUrl: resolvedUrl,
        description: `Official course assignment and syllabus document loaded from ${fileName}`,
      });
    }
  });

  return dynamicItems.length > 0 ? [...dynamicItems, ...defaultList] : defaultList;
}

export function buildQuestionPapersList() {
  const defaultList = [
    {
      id: 'qp_adsa_2023_mid',
      title: 'Mid-Semester Examination 2023',
      subject: 'Advanced Data Structures',
      year: '2023',
      type: 'Mid-Semester',
      fileUrl: '/records/Question Paper Images/ADSA/2023_Mid_Semester_Exam.png',
      format: 'image',
    },
    {
      id: 'qp_adsa_2024_end',
      title: 'End-Semester Final Exam 2024',
      subject: 'Advanced Data Structures',
      year: '2024',
      type: 'End-Semester',
      fileUrl: '/records/Question Paper Images/ADSA/2024_End_Semester_Exam.pdf',
      format: 'pdf',
    },
    {
      id: 'qp_ml_2023_end',
      title: 'End-Semester Examination 2023',
      subject: 'Machine Learning & AI',
      year: '2023',
      type: 'End-Semester',
      fileUrl: '/records/Question Paper Images/ML_AI/2023_End_Semester_Exam.pdf',
      format: 'pdf',
    },
    {
      id: 'qp_ds_2024_test',
      title: 'Class Assessment Test 2024',
      subject: 'Distributed Systems',
      year: '2024',
      type: 'Class Test',
      fileUrl: '/records/Question Paper Images/Distributed_Systems/2024_Class_Test.png',
      format: 'image',
    },
  ];

  // Dynamically scan any local files in /records/Question Papers
  const dynamicItems = [];
  let scanIndex = 1;
  Object.keys(documentAssetFiles).forEach((path) => {
    if (path.toLowerCase().includes('question')) {
      const parts = path.split('/');
      const fileName = parts[parts.length - 1];
      const rawSubject = parts.length > 3 ? parts[parts.length - 2] : 'MSc Exam Archive';
      const subject = rawSubject === 'Question Papers' ? 'MSc Exam Archive' : rawSubject;
      const ext = fileName.split('.').pop().toLowerCase();
      const isImg = ['png', 'jpg', 'jpeg', 'webp', 'svg'].includes(ext);

      let cleanTitle = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      if (cleanTitle.toLowerCase().includes('screenshot')) {
        cleanTitle = `Question Paper Exam Scan - Set ${scanIndex} (${fileName.substring(11, 21)})`;
        scanIndex++;
      }

      const resolvedUrl = typeof documentAssetFiles[path] === 'string' 
        ? documentAssetFiles[path] 
        : (documentAssetFiles[path]?.default || path);

      dynamicItems.push({
        id: path.toLowerCase().replace(/[^\w]/g, '_'),
        title: cleanTitle,
        subject: subject,
        year: '2026',
        type: 'Archive Exam',
        fileUrl: resolvedUrl,
        format: isImg ? 'image' : 'pdf',
      });
    }
  });

  return dynamicItems.length > 0 ? [...dynamicItems, ...defaultList] : defaultList;
}

export function buildHandwrittenNotesList() {
  const defaultList = [
    {
      id: 'hw_adsa_lec1',
      title: 'Lecture 1: Asymptotic Notation & Proofs',
      subject: 'Advanced Data Structures',
      date: 'July 10, 2026',
      pages: 12,
      fileUrl: '/public/assets/handwritten/Lecture-1-Asymptotic-Notation.pdf',
      tags: ['Proof', 'Big-O', 'Limits'],
    },
    {
      id: 'hw_adsa_lec5',
      title: 'Lecture 5: AVL Tree Rotations & Heights',
      subject: 'Advanced Data Structures',
      date: 'July 18, 2026',
      pages: 8,
      fileUrl: '/public/assets/handwritten/Lecture-5-AVL-Tree-Rotations.pdf',
      tags: ['Diagrams', 'Rotations', 'AVL'],
    },
    {
      id: 'hw_ml_lec3',
      title: 'Lecture 3: Backpropagation & Chain Rule Derivation',
      subject: 'Machine Learning & AI',
      date: 'July 22, 2026',
      pages: 15,
      fileUrl: '/public/assets/handwritten/Lecture-3-Backpropagation-Derivation.pdf',
      tags: ['Calculus', 'Matrix Math', 'Neural Nets'],
    },
  ];

  // Dynamically scan any local files in /records/Handwritten Notes or /assets/handwritten
  const dynamicItems = [];
  Object.keys(documentAssetFiles).forEach((path) => {
    if (path.toLowerCase().includes('handwritten') || path.toLowerCase().includes('note')) {
      const parts = path.split('/');
      const fileName = parts[parts.length - 1];
      const rawSubject = parts.length > 3 ? parts[parts.length - 2] : 'Principles of Compiler Design';
      let subject = rawSubject === 'Handwritten Notes' ? 'Principles of Compiler Design' : rawSubject;

      let cleanTitle = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      if (cleanTitle.toLowerCase().includes('compiler designs')) {
        cleanTitle = 'Principles of Compiler Design - Syllabus & Lecture Notes';
        subject = 'Principles of Compiler Design';
      }

      const resolvedUrl = typeof documentAssetFiles[path] === 'string' 
        ? documentAssetFiles[path] 
        : (documentAssetFiles[path]?.default || path);

      dynamicItems.push({
        id: path.toLowerCase().replace(/[^\w]/g, '_'),
        title: cleanTitle,
        subject: subject,
        date: 'July 2026',
        pages: 5,
        fileUrl: resolvedUrl,
        tags: ['CompilerDesign', 'Syllabus', 'Handwritten'],
      });
    }
  });

  return dynamicItems.length > 0 ? [...dynamicItems, ...defaultList] : defaultList;
}

