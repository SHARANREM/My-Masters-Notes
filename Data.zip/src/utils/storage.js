/**
 * Local Storage Persistence Manager for Rem Notes
 */

const STORAGE_KEYS = {
  BOOKMARKS: 'rem_notes_bookmarks_v1',
  RECENT: 'rem_notes_recent_v1',
  EXPANDED_FOLDERS: 'rem_notes_expanded_folders_v1',
  PINNED: 'rem_notes_pinned_v1',
};

// Bookmarks
export function getBookmarks() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.BOOKMARKS);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function toggleBookmark(lesson) {
  const bookmarks = getBookmarks();
  const exists = bookmarks.some((b) => b.id === lesson.id);
  let updated;
  if (exists) {
    updated = bookmarks.filter((b) => b.id !== lesson.id);
  } else {
    updated = [
      {
        id: lesson.id,
        title: lesson.title,
        subjectName: lesson.subjectName,
        unitName: lesson.unitName,
        filePath: lesson.filePath,
        savedAt: new Date().toISOString(),
      },
      ...bookmarks,
    ];
  }
  localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(updated));
  return updated;
}

export function isBookmarked(lessonId) {
  const bookmarks = getBookmarks();
  return bookmarks.some((b) => b.id === lessonId);
}

// Recently Viewed
export function getRecentHistory() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.RECENT);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function addRecentItem(lesson) {
  if (!lesson || !lesson.id) return [];
  const history = getRecentHistory().filter((item) => item.id !== lesson.id);
  const newItem = {
    id: lesson.id,
    title: lesson.title,
    subjectName: lesson.subjectName,
    unitName: lesson.unitName,
    filePath: lesson.filePath,
    viewedAt: new Date().toISOString(),
  };
  const updated = [newItem, ...history].slice(0, 15); // Keep top 15 recent
  localStorage.setItem(STORAGE_KEYS.RECENT, JSON.stringify(updated));
  return updated;
}

// Expanded Sidebar Folders
export function getExpandedFolders() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.EXPANDED_FOLDERS);
    return data ? JSON.parse(data) : {};
  } catch (e) {
    return {};
  }
}

export function saveExpandedFolders(expandedState) {
  localStorage.setItem(STORAGE_KEYS.EXPANDED_FOLDERS, JSON.stringify(expandedState));
}
